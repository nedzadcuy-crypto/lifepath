package com.example

import com.example.economy.EconomyEngine
import com.example.model.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testChildUnderLegalWorkingAgeHasNoAutomatedIncome() {
    val childProfile = CharacterProfile(
      id = "child_1",
      name = "Budi Kecil",
      age = 9,
      occupation = "Murid SD"
    )
    val childFinance = FinancialState(
      cash = 50_000L,
      monthlyIncome = 500_000L, // even if erroneously set
      monthlyExpense = 100_000L
    )

    val result = EconomyEngine.evaluateYearlyFlow(
      profile = childProfile,
      finance = childFinance,
      age = 10,
      year = 2025
    )

    // Child must NOT receive automated employment salary
    assertEquals(0L, result.totalInflow)
    assertEquals(0L, result.totalOutflow) // basic expenses covered by family
    assertEquals(50_000L, result.updatedFinance.cash)
  }

  @Test
  fun testProcessTransactionPreventsNegativeBalance() {
    val finance = FinancialState(cash = 100_000L)
    val (updatedFinance, tx) = EconomyEngine.processTransaction(
      currentFinance = finance,
      age = 18,
      year = 2024,
      type = TransactionType.SHOP_PURCHASE,
      amount = -250_000L,
      description = "Membeli pakaian mahal",
      source = "Toko"
    )

    // Transaction must fail
    assertNull(tx)
    assertEquals(100_000L, updatedFinance.cash)
  }

  @Test
  fun testProcessTransactionRecordsCashFlow() {
    val finance = FinancialState(cash = 50_000L)
    val (updatedFinance, tx) = EconomyEngine.processTransaction(
      currentFinance = finance,
      age = 10,
      year = 2024,
      type = TransactionType.BUSINESS_INCOME,
      amount = 40_000L,
      description = "Penjualan es krim dari rumah (modal Rp 0)",
      source = "Usaha Kecil"
    )

    assertNotNull(tx)
    assertEquals(90_000L, updatedFinance.cash)
    assertEquals(1, updatedFinance.transactions.size)
    assertEquals(TransactionType.BUSINESS_INCOME, updatedFinance.transactions.first().type)
  }

  @Test
  fun testEmployedAdultReceivesFormalSalary() {
    val adultProfile = CharacterProfile(
      id = "adult_1",
      name = "Aditya Pratama",
      age = 22,
      occupation = "Software Developer"
    )
    val adultFinance = FinancialState(
      cash = 2_000_000L,
      monthlyIncome = 8_000_000L,
      monthlyExpense = 2_500_000L
    )

    val result = EconomyEngine.evaluateYearlyFlow(
      profile = adultProfile,
      finance = adultFinance,
      age = 23,
      year = 2025
    )

    val expectedInflow = 8_000_000L * 12
    val expectedOutflow = 2_500_000L * 12
    val expectedNet = expectedInflow - expectedOutflow

    assertEquals(expectedInflow, result.totalInflow)
    assertEquals(expectedOutflow, result.totalOutflow)
    assertEquals(expectedNet, result.netCashFlow)
    assertEquals(2_000_000L + expectedNet, result.updatedFinance.cash)
  }
}
