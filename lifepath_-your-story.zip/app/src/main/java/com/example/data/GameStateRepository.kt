package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.*
import org.json.JSONArray
import org.json.JSONObject

class GameStateRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("lifepath_game_state", Context.MODE_PRIVATE)

    fun hasSavedGame(): Boolean {
        return prefs.contains("character_profile")
    }

    fun saveGame(
        profile: CharacterProfile,
        stats: LifeStats,
        finance: FinancialState,
        relationships: List<Relationship>,
        timeline: List<TimelineEvent>,
        achievements: List<GameAchievement>
    ) {
        val editor = prefs.edit()

        // 1. Profile
        val profObj = JSONObject().apply {
            put("id", profile.id)
            put("name", profile.name)
            put("gender", profile.gender.name)
            put("birthYear", profile.birthYear)
            put("currentYear", profile.currentYear)
            put("age", profile.age)
            put("birthCity", profile.birthCity)
            put("occupation", profile.occupation)
            put("educationLevel", profile.educationLevel)
            put("lifeStageDescription", profile.lifeStageDescription)
            put("isAlive", profile.isAlive)
            put("causeOfDeath", profile.causeOfDeath ?: "")
            put("backgroundTrait", profile.backgroundTrait)

            // Avatar appearance
            val avObj = JSONObject().apply {
                put("skinTone", profile.avatar.skinTone)
                put("hairStyle", profile.avatar.hairStyle)
                put("hairColor", profile.avatar.hairColor)
                put("topStyle", profile.avatar.topStyle)
                put("topColor", profile.avatar.topColor)
                put("bottomStyle", profile.avatar.bottomStyle)
                put("bottomColor", profile.avatar.bottomColor)
                put("shoesStyle", profile.avatar.shoesStyle)
                put("shoesColor", profile.avatar.shoesColor)
                put("accessory", profile.avatar.accessory)
            }
            put("avatar", avObj)

            // Personality traits
            val traitsArr = JSONArray()
            profile.personalityTraits.forEach { traitsArr.put(it) }
            put("personalityTraits", traitsArr)

            // Owned clothing IDs
            val clothingArr = JSONArray()
            profile.ownedClothingIds.forEach { clothingArr.put(it) }
            put("ownedClothingIds", clothingArr)
        }
        editor.putString("character_profile", profObj.toString())

        // 2. Stats
        val statsObj = JSONObject().apply {
            put("health", stats.health)
            put("happiness", stats.happiness)
            put("intellect", stats.intellect)
            put("reputation", stats.reputation)
            put("energy", stats.energy)
        }
        editor.putString("life_stats", statsObj.toString())

        // 3. Finance
        val finObj = JSONObject().apply {
            put("cash", finance.cash)
            put("monthlyIncome", finance.monthlyIncome)
            put("monthlyExpense", finance.monthlyExpense)

            val assetsArr = JSONArray()
            finance.assets.forEach { asset ->
                assetsArr.put(JSONObject().apply {
                    put("id", asset.id)
                    put("name", asset.name)
                    put("value", asset.value)
                    put("category", asset.category)
                    put("monthlyMaintenance", asset.monthlyMaintenance)
                    put("monthlyIncomeContribution", asset.monthlyIncomeContribution)
                })
            }
            put("assets", assetsArr)

            val debtsArr = JSONArray()
            finance.debts.forEach { debt ->
                debtsArr.put(JSONObject().apply {
                    put("id", debt.id)
                    put("name", debt.name)
                    put("totalAmount", debt.totalAmount)
                    put("monthlyPayment", debt.monthlyPayment)
                })
            }
            put("debts", debtsArr)

            val txArr = JSONArray()
            finance.transactions.take(60).forEach { tx ->
                txArr.put(JSONObject().apply {
                    put("id", tx.id)
                    put("age", tx.age)
                    put("year", tx.year)
                    put("type", tx.type.name)
                    put("amount", tx.amount)
                    put("description", tx.description)
                    put("source", tx.source)
                    put("timestamp", tx.timestamp)
                })
            }
            put("transactions", txArr)
        }
        editor.putString("financial_state", finObj.toString())

        // 4. Relationships
        val relArr = JSONArray()
        relationships.forEach { rel ->
            relArr.put(JSONObject().apply {
                put("id", rel.id)
                put("name", rel.name)
                put("relationType", rel.relationType.name)
                put("age", rel.age)
                put("closeness", rel.closeness)
                put("personality", rel.personality)
                put("occupation", rel.occupation)
                put("statusDescription", rel.statusDescription)
            })
        }
        editor.putString("relationships", relArr.toString())

        // 5. Timeline Events
        val timeArr = JSONArray()
        timeline.forEach { ev ->
            timeArr.put(JSONObject().apply {
                put("id", ev.id)
                put("age", ev.age)
                put("year", ev.year)
                put("text", ev.text)
                put("category", ev.category.name)
            })
        }
        editor.putString("timeline", timeArr.toString())

        // 6. Achievements
        val achArr = JSONArray()
        achievements.forEach { ach ->
            achArr.put(JSONObject().apply {
                put("id", ach.id)
                put("title", ach.title)
                put("description", ach.description)
                put("iconName", ach.iconName)
                put("unlockedAtAge", ach.unlockedAtAge ?: -1)
            })
        }
        editor.putString("achievements", achArr.toString())

        editor.apply()
    }

    fun loadProfile(): CharacterProfile {
        val str = prefs.getString("character_profile", null) ?: return createDefaultProfile()
        val obj = JSONObject(str)

        val avObj = obj.optJSONObject("avatar")
        val avatar = if (avObj != null) {
            AvatarAppearance(
                skinTone = avObj.optString("skinTone", "MEDIUM"),
                hairStyle = avObj.optString("hairStyle", "SHORT_CURLY"),
                hairColor = avObj.optString("hairColor", "BLACK"),
                topStyle = avObj.optString("topStyle", "T_SHIRT"),
                topColor = avObj.optString("topColor", "ELECTRIC_TEAL"),
                bottomStyle = avObj.optString("bottomStyle", "JEANS"),
                bottomColor = avObj.optString("bottomColor", "DARK_DENIM"),
                shoesStyle = avObj.optString("shoesStyle", "SNEAKERS"),
                shoesColor = avObj.optString("shoesColor", "WHITE"),
                accessory = avObj.optString("accessory", "NONE")
            )
        } else AvatarAppearance()

        val traitsList = mutableListOf<String>()
        val traitsArr = obj.optJSONArray("personalityTraits")
        if (traitsArr != null) {
            for (i in 0 until traitsArr.length()) {
                traitsList.add(traitsArr.getString(i))
            }
        }
        if (traitsList.isEmpty()) {
            traitsList.addAll(listOf("Ambisius", "Kreatif"))
        }

        val clothingList = mutableListOf<String>()
        val clothingArr = obj.optJSONArray("ownedClothingIds")
        if (clothingArr != null) {
            for (i in 0 until clothingArr.length()) {
                clothingList.add(clothingArr.getString(i))
            }
        }
        if (clothingList.isEmpty()) {
            clothingList.addAll(listOf("item_tshirt_teal", "item_jeans_dark", "item_sneakers_white"))
        }

        return CharacterProfile(
            id = obj.optString("id", "char_1"),
            name = obj.optString("name", "Aditya Pratama"),
            gender = try { Gender.valueOf(obj.optString("gender", Gender.MALE.name)) } catch (_: Exception) { Gender.MALE },
            birthYear = obj.optInt("birthYear", 2002),
            currentYear = obj.optInt("currentYear", 2020),
            age = obj.optInt("age", 18),
            birthCity = obj.optString("birthCity", "Jakarta"),
            occupation = obj.optString("occupation", "Lulusan SMA"),
            educationLevel = obj.optString("educationLevel", "SMA"),
            lifeStageDescription = obj.optString("lifeStageDescription", "Menentukan Arah Masa Depan"),
            isAlive = obj.optBoolean("isAlive", true),
            causeOfDeath = obj.optString("causeOfDeath").takeIf { it.isNotBlank() },
            backgroundTrait = obj.optString("backgroundTrait", "Keluarga Menengah Pekerja Keras"),
            avatar = avatar,
            personalityTraits = traitsList,
            ownedClothingIds = clothingList
        )
    }

    fun loadStats(): LifeStats {
        val str = prefs.getString("life_stats", null) ?: return LifeStats()
        val obj = JSONObject(str)
        return LifeStats(
            health = obj.optInt("health", 85),
            happiness = obj.optInt("happiness", 80),
            intellect = obj.optInt("intellect", 75),
            reputation = obj.optInt("reputation", 60),
            energy = obj.optInt("energy", 90)
        ).clamped()
    }

    fun loadFinance(): FinancialState {
        val str = prefs.getString("financial_state", null) ?: return createDefaultFinance(18)
        val obj = JSONObject(str)

        val assetsList = mutableListOf<AssetItem>()
        val assetsArr = obj.optJSONArray("assets")
        if (assetsArr != null) {
            for (i in 0 until assetsArr.length()) {
                val a = assetsArr.optJSONObject(i) ?: continue
                assetsList.add(AssetItem(
                    id = a.optString("id", "ast_$i"),
                    name = a.optString("name", "Aset"),
                    value = a.optLong("value", 0L),
                    category = a.optString("category", "Lainnya"),
                    monthlyMaintenance = a.optLong("monthlyMaintenance", 0L),
                    monthlyIncomeContribution = a.optLong("monthlyIncomeContribution", 0L)
                ))
            }
        }

        val debtList = mutableListOf<DebtItem>()
        val debtsArr = obj.optJSONArray("debts")
        if (debtsArr != null) {
            for (i in 0 until debtsArr.length()) {
                val d = debtsArr.optJSONObject(i) ?: continue
                debtList.add(DebtItem(
                    id = d.optString("id", "debt_$i"),
                    name = d.optString("name", "Utang"),
                    totalAmount = d.optLong("totalAmount", 0L),
                    monthlyPayment = d.optLong("monthlyPayment", 0L)
                ))
            }
        }

        val txList = mutableListOf<CashTransaction>()
        val txArr = obj.optJSONArray("transactions")
        if (txArr != null) {
            for (i in 0 until txArr.length()) {
                val t = txArr.optJSONObject(i) ?: continue
                txList.add(CashTransaction(
                    id = t.optString("id", "tx_$i"),
                    age = t.optInt("age", 0),
                    year = t.optInt("year", 2024),
                    type = try { TransactionType.valueOf(t.optString("type", TransactionType.OTHER.name)) } catch (_: Exception) { TransactionType.OTHER },
                    amount = t.optLong("amount", 0L),
                    description = t.optString("description", ""),
                    source = t.optString("source", ""),
                    timestamp = t.optLong("timestamp", System.currentTimeMillis())
                ))
            }
        }

        return FinancialState(
            cash = obj.optLong("cash", 0L),
            monthlyIncome = obj.optLong("monthlyIncome", 0L),
            monthlyExpense = obj.optLong("monthlyExpense", 0L),
            assets = assetsList,
            debts = debtList,
            transactions = txList
        )
    }

    fun loadRelationships(): List<Relationship> {
        val str = prefs.getString("relationships", null) ?: return createDefaultRelationships(18)
        val arr = JSONArray(str)
        val list = mutableListOf<Relationship>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            list.add(Relationship(
                id = obj.optString("id", "rel_$i"),
                name = obj.optString("name", "Kerabat"),
                relationType = try { RelationType.valueOf(obj.optString("relationType", RelationType.FRIEND.name)) } catch (_: Exception) { RelationType.FRIEND },
                age = obj.optInt("age", 45),
                closeness = obj.optInt("closeness", 50),
                personality = obj.optString("personality", "Ramah"),
                occupation = obj.optString("occupation", "Wiraswasta"),
                statusDescription = obj.optString("statusDescription", "Hubungan baik")
            ))
        }
        return list
    }

    fun loadTimeline(): List<TimelineEvent> {
        val str = prefs.getString("timeline", null) ?: return createDefaultTimeline(18)
        val arr = JSONArray(str)
        val list = mutableListOf<TimelineEvent>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            list.add(TimelineEvent(
                id = obj.optString("id", "ev_$i"),
                age = obj.optInt("age", 18),
                year = obj.optInt("year", 2020),
                text = obj.optString("text", ""),
                category = try { EventCategory.valueOf(obj.optString("category", EventCategory.GENERAL.name)) } catch (_: Exception) { EventCategory.GENERAL }
            ))
        }
        return list
    }

    fun loadAchievements(): List<GameAchievement> {
        val str = prefs.getString("achievements", null) ?: return createInitialAchievements()
        val arr = JSONArray(str)
        val list = mutableListOf<GameAchievement>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val ageVal = obj.optInt("unlockedAtAge", -1)
            list.add(GameAchievement(
                id = obj.optString("id", "ach_$i"),
                title = obj.optString("title", ""),
                description = obj.optString("description", ""),
                iconName = obj.optString("iconName", "star"),
                unlockedAtAge = if (ageVal >= 0) ageVal else null
            ))
        }
        return list
    }

    fun clearGame() {
        prefs.edit().clear().apply()
    }

    // Default factory initializers
    fun createDefaultProfile(
        name: String = "Aditya Pratama",
        gender: Gender = Gender.MALE,
        startAge: Int = 18,
        birthCity: String = "Jakarta",
        backgroundTrait: String = "Keluarga Menengah Pekerja Keras",
        avatar: AvatarAppearance = AvatarAppearance(),
        personalityTraits: List<String> = listOf("Ambisius", "Kreatif")
    ): CharacterProfile {
        val currentYear = 2024
        val birthYear = currentYear - startAge
        val (occupation, educationLevel, stageDesc) = when {
            startAge == 0 -> Triple("Bayi", "Belum Sekolah", "Masa Awal Kehidupan")
            startAge < 6 -> Triple("Balita", "PAUD", "Masa Kanak-kanak Awal")
            startAge < 13 -> Triple("Murid SD", "SD", "Pendidikan Dasar")
            startAge < 16 -> Triple("Siswa SMP", "SMP", "Masa Remaja Awal")
            startAge < 19 -> Triple("Siswa SMA", "SMA", "Masa Remaja Akhir")
            startAge < 25 -> Triple("Mahasiswa / Pencari Kerja", "SMA", "Meniti Karier Awal")
            else -> Triple("Karyawan Swasta", "S1", "Masa Dewasa")
        }

        return CharacterProfile(
            name = name,
            gender = gender,
            birthYear = birthYear,
            currentYear = currentYear,
            age = startAge,
            birthCity = birthCity,
            occupation = occupation,
            educationLevel = educationLevel,
            lifeStageDescription = stageDesc,
            backgroundTrait = backgroundTrait,
            avatar = avatar,
            personalityTraits = personalityTraits
        )
    }

    fun createDefaultFinance(startAge: Int): FinancialState {
        return when {
            startAge == 0 -> FinancialState(
                cash = 0L, // Bayi tidak memegang uang sendiri
                monthlyIncome = 0L,
                monthlyExpense = 0L,
                assets = emptyList(),
                transactions = emptyList()
            )
            startAge < 13 -> FinancialState(
                cash = 50_000L, // Uang celengan kecil
                monthlyIncome = 0L, // Belum bekerja, tidak ada pemasukan otomatis
                monthlyExpense = 0L, // Kebutuhan hidup ditanggung keluarga
                assets = listOf(AssetItem("ast_toy", "Koleksi Mainan & Sepeda Anak", 600_000L, "Barang")),
                transactions = listOf(
                    CashTransaction(
                        id = "tx_init_piggy",
                        age = startAge,
                        year = 2024,
                        type = TransactionType.ALLOWANCE_GIFT,
                        amount = 50_000L,
                        description = "Celengan uang saku masa kecil",
                        source = "Tabungan Celengan"
                    )
                )
            )
            startAge < 18 -> FinancialState(
                cash = 250_000L,
                monthlyIncome = 0L, // Siswa sekolah belum bekerja
                monthlyExpense = 0L, // Hidup bersama orang tua
                assets = listOf(AssetItem("ast_phone", "Smartphone Android", 1_800_000L, "Elektronik")),
                transactions = listOf(
                    CashTransaction(
                        id = "tx_init_teen",
                        age = startAge,
                        year = 2024,
                        type = TransactionType.ALLOWANCE_GIFT,
                        amount = 250_000L,
                        description = "Tabungan sisa uang jajan sekolah",
                        source = "Tabungan Siswa"
                    )
                )
            )
            else -> FinancialState(
                cash = 2_000_000L,
                monthlyIncome = 0L, // Belum mendapat pekerjaan
                monthlyExpense = 1_200_000L, // Biaya hidup mandiri (makan, transportasi)
                assets = listOf(
                    AssetItem("ast_phone", "Smartphone Android", 2_500_000L, "Elektronik"),
                    AssetItem("ast_laptop", "Laptop Pribadi", 6_000_000L, "Elektronik")
                ),
                transactions = listOf(
                    CashTransaction(
                        id = "tx_init_adult",
                        age = startAge,
                        year = 2024,
                        type = TransactionType.ALLOWANCE_GIFT,
                        amount = 2_000_000L,
                        description = "Tabungan awal fase dewasa mandiri",
                        source = "Tabungan Pribadi"
                    )
                )
            )
        }
    }

    fun createDefaultRelationships(startAge: Int): List<Relationship> {
        val fatherAge = startAge + 28
        val motherAge = startAge + 26
        return listOf(
            Relationship(
                id = "rel_father",
                name = "Bambang Sudiro",
                relationType = RelationType.FATHER,
                age = fatherAge,
                closeness = 85,
                personality = "Tegas, pekerja keras, dan protektif",
                occupation = "PNS / Pegawai Lapangan",
                statusDescription = "Hubungan hangat dan saling menghormati"
            ),
            Relationship(
                id = "rel_mother",
                name = "Dewi Lestari",
                relationType = RelationType.MOTHER,
                age = motherAge,
                closeness = 92,
                personality = "Penuh kasih, gemar memasak, dan perhatian",
                occupation = "Ibu Rumah Tangga / Pengrajin",
                statusDescription = "Sangat menyayangimu tanpa syarat"
            ),
            Relationship(
                id = "rel_friend",
                name = "Rizky Ramadhan",
                relationType = RelationType.FRIEND,
                age = startAge,
                closeness = 78,
                personality = "Humoris, loyal, dan suka bermain game",
                occupation = "Pelajar / Mahasiswa",
                statusDescription = "Teman akrab sejak masa sekolah"
            )
        )
    }

    fun createDefaultTimeline(startAge: Int): List<TimelineEvent> {
        val list = mutableListOf<TimelineEvent>()
        list.add(TimelineEvent("ev_birth", 0, 2024 - startAge, "Kamu lahir ke dunia di rumah sakit kota dengan selamat dan disambut bahagia oleh kedua orang tuamu.", EventCategory.MILESTONE))
        if (startAge >= 6) {
            list.add(TimelineEvent("ev_sd", 6, 2024 - startAge + 6, "Hari pertamamu masuk Sekolah Dasar. Kamu berkenalan dengan teman-teman baru.", EventCategory.EDUCATION))
        }
        if (startAge >= 12) {
            list.add(TimelineEvent("ev_smp", 12, 2024 - startAge + 12, "Lulus dari SD dan melanjutkan pendidikan ke Sekolah Menengah Pertama.", EventCategory.EDUCATION))
        }
        if (startAge >= 15) {
            list.add(TimelineEvent("ev_sma", 15, 2024 - startAge + 15, "Masuk jenjang SMA. Dunia pergaulanmu semakin luas dan kamu mulai mencari jati diri.", EventCategory.EDUCATION))
        }
        if (startAge >= 18) {
            list.add(TimelineEvent("ev_grad_sma", 18, 2024 - startAge + 18, "Merayakan kelulusan SMA. Kini pilihan hidup sepenuhnya berada di genggamanmu.", EventCategory.MILESTONE))
        }
        return list.reversed()
    }

    fun createInitialAchievements(): List<GameAchievement> {
        return listOf(
            GameAchievement("ach_first_step", "Langkah Pertama", "Memulai perjalanan kehidupan di LIFEPATH.", "footsteps", 0),
            GameAchievement("ach_scholar", "Pecinta Ilmu", "Mencapai nilai kecerdasan 90 atau lebih.", "school", null),
            GameAchievement("ach_first_job", "Mandiri Finansial", "Mendapatkan pekerjaan atau sumber penghasilan pertama.", "work", null),
            GameAchievement("ach_boss", "Pengusaha Mandiri", "Mendirikan bisnis pribadi yang menguntungkan.", "business", null),
            GameAchievement("ach_wealthy", "Sultan Muda", "Mengumpulkan total kekayaan lebih dari Rp 100.000.000.", "money", null),
            GameAchievement("ach_centenarian", "Usia Emas", "Bertahan hidup dan merayakan ulang tahun ke-75.", "elder", null),
            GameAchievement("ach_beloved", "Sosok Dicintai", "Memiliki 3 hubungan dengan tingkat kedekatan di atas 90%.", "heart", null)
        )
    }
}
