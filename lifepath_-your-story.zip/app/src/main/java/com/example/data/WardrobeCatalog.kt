package com.example.data

import com.example.model.ClothingCategory
import com.example.model.ShopClothingItem

object WardrobeCatalog {
    val shopItems = listOf(
        // Tops
        ShopClothingItem(
            id = "item_tshirt_teal",
            name = "Kaos Polos Electric Teal",
            category = ClothingCategory.TOP,
            styleKey = "T_SHIRT",
            colorKey = "ELECTRIC_TEAL",
            price = 150_000L,
            reputationBonus = 1,
            description = "Kaos katun santai dengan warna khas LIFEPATH yang nyaman dipakai harian."
        ),
        ShopClothingItem(
            id = "item_hoodie_charcoal",
            name = "Hoodie Oversized Charcoal",
            category = ClothingCategory.TOP,
            styleKey = "HOODIE",
            colorKey = "CHARCOAL",
            price = 450_000L,
            reputationBonus = 3,
            description = "Hoodie tebal bergaya streetwear modern dengan nuansa gelap misterius."
        ),
        ShopClothingItem(
            id = "item_kemeja_white",
            name = "Kemeja Formal Putih Katun",
            category = ClothingCategory.TOP,
            styleKey = "KEMEJA",
            colorKey = "WHITE",
            price = 550_000L,
            reputationBonus = 5,
            description = "Kemeja berkerah rapi, sempurna untuk wawancara kerja dan rapat kantor."
        ),
        ShopClothingItem(
            id = "item_batik_amber",
            name = "Kemeja Batik Sutra Amber",
            category = ClothingCategory.TOP,
            styleKey = "BATIK",
            colorKey = "AMBER",
            price = 1_250_000L,
            reputationBonus = 9,
            description = "Batik tulis bermotif megah khas Nusantara dengan aksen emas berwibawa."
        ),
        ShopClothingItem(
            id = "item_jaket_kulit",
            name = "Jaket Kulit Biker Hitam",
            category = ClothingCategory.TOP,
            styleKey = "JAKET_KULIT",
            colorKey = "CHARCOAL",
            price = 2_500_000L,
            reputationBonus = 12,
            description = "Jaket kulit asli yang memberikan aura karismatik dan tangguh."
        ),
        ShopClothingItem(
            id = "item_blazer_navy",
            name = "Blazer Eksekutif Navy Blue",
            category = ClothingCategory.TOP,
            styleKey = "BLAZER",
            colorKey = "NAVY",
            price = 4_500_000L,
            reputationBonus = 18,
            description = "Jas blazer pesanan khusus untuk pengusaha dan eksekutif papan atas."
        ),

        // Bottoms
        ShopClothingItem(
            id = "item_jeans_dark",
            name = "Celana Jeans Dark Denim",
            category = ClothingCategory.BOTTOM,
            styleKey = "JEANS",
            colorKey = "DARK_DENIM",
            price = 350_000L,
            reputationBonus = 2,
            description = "Jeans stretch tahan lama yang cocok dipadukan dengan berbagai atasan."
        ),
        ShopClothingItem(
            id = "item_chinos_khaki",
            name = "Celana Chinos Khaki Slim",
            category = ClothingCategory.BOTTOM,
            styleKey = "CHINOS",
            colorKey = "KHAKI",
            price = 420_000L,
            reputationBonus = 4,
            description = "Celana santai namun rapi untuk suasana semi-formal dan nongkrong."
        ),
        ShopClothingItem(
            id = "item_celana_formal",
            name = "Celana Bahan Formal Hitam",
            category = ClothingCategory.BOTTOM,
            styleKey = "CELANA_BAHAN",
            colorKey = "BLACK",
            price = 650_000L,
            reputationBonus = 6,
            description = "Celana kain berlipit rapi yang memancarkan profesionalisme."
        ),
        ShopClothingItem(
            id = "item_jogger_grey",
            name = "Jogger Pants Urban Grey",
            category = ClothingCategory.BOTTOM,
            styleKey = "JOGGER",
            colorKey = "GREY",
            price = 380_000L,
            reputationBonus = 3,
            description = "Celana olahraga fleksibel untuk mobilitas tinggi dan kenyamanan maksimal."
        ),

        // Shoes
        ShopClothingItem(
            id = "item_sneakers_white",
            name = "Sneakers Putih Klasik",
            category = ClothingCategory.SHOES,
            styleKey = "SNEAKERS",
            colorKey = "WHITE",
            price = 600_000L,
            reputationBonus = 3,
            description = "Sepatu kets putih abadi yang fleksibel untuk segala acara kasual."
        ),
        ShopClothingItem(
            id = "item_shoes_leather",
            name = "Sepatu Kulit Oxford Cokelat",
            category = ClothingCategory.SHOES,
            styleKey = "LEATHER_SHOES",
            colorKey = "BROWN",
            price = 1_500_000L,
            reputationBonus = 8,
            description = "Sepatu pantofel berkelas tinggi dengan kulit mengkilap tahan air."
        ),
        ShopClothingItem(
            id = "item_boots_black",
            name = "Chelsea Boots Kulit Hitam",
            category = ClothingCategory.SHOES,
            styleKey = "BOOTS",
            colorKey = "BLACK",
            price = 2_100_000L,
            reputationBonus = 10,
            description = "Boots berdesain tegas dan elegan yang memperkuat wibawa langkahmu."
        ),

        // Accessories
        ShopClothingItem(
            id = "item_acc_glasses",
            name = "Kacamata Frame Modern",
            category = ClothingCategory.ACCESSORY,
            styleKey = "KACAMATA_MODERN",
            colorKey = "BLACK",
            price = 450_000L,
            reputationBonus = 4,
            description = "Kacamata dengan bingkai tipis elegan yang menambah kesan cerdas."
        ),
        ShopClothingItem(
            id = "item_acc_beanie",
            name = "Topi Beanie Rajut Hangat",
            category = ClothingCategory.ACCESSORY,
            styleKey = "TOPI_BEANIE",
            colorKey = "AMBER",
            price = 200_000L,
            reputationBonus = 2,
            description = "Topi kupluk bernuansa amber yang memberikan gaya santai artistik."
        ),
        ShopClothingItem(
            id = "item_acc_necklace",
            name = "Kalung Emas Rantai Tipis",
            category = ClothingCategory.ACCESSORY,
            styleKey = "KALUNG_EMAS",
            colorKey = "AMBER",
            price = 3_500_000L,
            reputationBonus = 14,
            description = "Aksesoris emas murni berkilau yang menarik perhatian sekitar."
        ),
        ShopClothingItem(
            id = "item_acc_watch",
            name = "Jam Tangan Chrono Mewah",
            category = ClothingCategory.ACCESSORY,
            styleKey = "JAM_TANGAN",
            colorKey = "ELECTRIC_TEAL",
            price = 8_500_000L,
            reputationBonus = 22,
            description = "Jam tangan mewah dengan bezel presisi tinggi dan status prestisius."
        )
    )
}
