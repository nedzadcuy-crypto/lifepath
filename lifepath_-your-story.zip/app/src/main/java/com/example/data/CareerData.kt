package com.example.data

import com.example.model.JobOpportunity

object CareerData {
    val availableJobs = listOf(
        JobOpportunity(
            id = "job_barista",
            title = "Barista & Kasir Cafe",
            company = "Kopi Teman Santai",
            minAge = 18,
            minIntellect = 40,
            minReputation = 30,
            monthlySalary = 3_500_000L,
            educationRequired = "SMA",
            description = "Meracik kopi kekinian dan melayani pelanggan dengan senyuman hangat."
        ),
        JobOpportunity(
            id = "job_admin",
            title = "Staf Administrasi & Data",
            company = "PT Nusantara Logistik",
            minAge = 19,
            minIntellect = 55,
            minReputation = 40,
            monthlySalary = 4_800_000L,
            educationRequired = "SMA",
            description = "Menginput dokumen operasional, arsip berkas, dan laporan harian kantor."
        ),
        JobOpportunity(
            id = "job_junior_dev",
            title = "Junior Software Developer",
            company = "Digital Horizon Tech",
            minAge = 19,
            minIntellect = 70,
            minReputation = 50,
            monthlySalary = 8_500_000L,
            educationRequired = "SMA/Kuliah",
            description = "Membangun fitur aplikasi mobile dan backend menggunakan teknologi modern."
        ),
        JobOpportunity(
            id = "job_uiux",
            title = "Product Designer (UI/UX)",
            company = "Studio Kreatif Nusantara",
            minAge = 20,
            minIntellect = 65,
            minReputation = 55,
            monthlySalary = 7_800_000L,
            educationRequired = "SMA/Diploma",
            description = "Merancang antarmuka pengguna yang estetik, intuitif, dan nyaman digunakan."
        ),
        JobOpportunity(
            id = "job_marketing",
            title = "Digital Marketing Specialist",
            company = "Agensi Viral Media",
            minAge = 20,
            minIntellect = 60,
            minReputation = 60,
            monthlySalary = 6_500_000L,
            educationRequired = "SMA/Diploma",
            description = "Menjalankan kampanye iklan media sosial, SEO, dan strategi konten kreatif."
        ),
        JobOpportunity(
            id = "job_senior_lead",
            title = "Lead Project Manager",
            company = "PT Global Inovasi Mega",
            minAge = 24,
            minIntellect = 80,
            minReputation = 75,
            monthlySalary = 16_000_000L,
            educationRequired = "S1",
            description = "Memimpin tim lintas divisi, mengelola anggaran proyek, dan eksekusi roadmap."
        ),
        JobOpportunity(
            id = "job_executive",
            title = "Direktur Operasional (COO)",
            company = "Holding Group Mandiri",
            minAge = 30,
            minIntellect = 88,
            minReputation = 85,
            monthlySalary = 35_000_000L,
            educationRequired = "S1/S2",
            description = "Mengambil keputusan strategis tingkat eksekutif untuk ekspansi bisnis nasional."
        )
    )
}
