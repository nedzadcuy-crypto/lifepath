package com.example.data

import com.example.model.PersonalityTrait

object PersonalityCatalog {
    val availableTraits = listOf(
        PersonalityTrait(
            id = "trait_ambitious",
            name = "Ambisius",
            description = "Fokus tinggi pada pencapaian karier, kekuasaan, dan target besar.",
            effectDescription = "+Reputasi & peluang promosi lebih tinggi, namun stres mudah naik."
        ),
        PersonalityTrait(
            id = "trait_creative",
            name = "Kreatif",
            description = "Memiliki daya imajinasi luas dan selalu menemukan ide di luar kebiasaan.",
            effectDescription = "+Peningkatan kecerdasan lebih cepat & ide bisnis unik berhasil."
        ),
        PersonalityTrait(
            id = "trait_empathetic",
            name = "Empatik",
            description = "Sangat peka terhadap perasaan orang lain dan senang membantu sesama.",
            effectDescription = "+Hubungan keluarga, teman, dan pasangan berkembang jauh lebih erat."
        ),
        PersonalityTrait(
            id = "trait_frugal",
            name = "Hemat & Cermat",
            description = "Menimbang setiap rupiah dengan matang dan menolak belanja impulsif.",
            effectDescription = "Pengeluaran hidup bulanan lebih hemat dan tabungan lebih cepat terkumpul."
        ),
        PersonalityTrait(
            id = "trait_risk_taker",
            name = "Pemberani Risiko",
            description = "Berani mengambil peluang besar yang ditakuti orang lain.",
            effectDescription = "Peluang laba bisnis spekulatif bisa berlipat ganda, namun waspadai risiko."
        ),
        PersonalityTrait(
            id = "trait_disciplined",
            name = "Disiplin & Teratur",
            description = "Menjaga jadwal tidur, makan sehat, dan konsistensi kerja setiap hari.",
            effectDescription = "Kesehatan jasmani dan energi tubuh lebih awet hingga usia senja."
        ),
        PersonalityTrait(
            id = "trait_charismatic",
            name = "Karismatik",
            description = "Punya daya tarik berbicara yang memikat dan memimpin secara alami.",
            effectDescription = "Reputasi sosial lebih mudah diakui publik dan rekan kerja."
        ),
        PersonalityTrait(
            id = "trait_introvert",
            name = "Introvert Tenang",
            description = "Menikmati kedamaian diri dan mampu berkonsentrasi dalam kesunyian.",
            effectDescription = "Kebahagiaan tetap tinggi saat belajar mandiri atau membaca buku."
        )
    )
}
