package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FinancialState
import com.example.ui.theme.*
import com.example.util.FormatUtils

@Composable
fun FinanceCard(
    finance: FinancialState,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(
                listOf(CharcoalOutline, CharcoalCard)
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountBalance,
                        contentDescription = null,
                        tint = AmberAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "KEUANGAN & ASET",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp,
                        color = TextSecondary
                    )
                }

                Text(
                    text = "Kekayaan Bersih: ${FormatUtils.formatRupiah(finance.netWorth)}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ElectricTeal
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Cash Balance Display
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CharcoalCardVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Saldo Kas Tersedia",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = FormatUtils.formatRupiah(finance.cash),
                            fontSize = 19.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (finance.cash > 0) ElectricTeal else RubyRed
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AmberGlow
                    ) {
                        Text(
                            text = "${finance.assets.size} Aset",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AmberAccent,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Monthly Income & Expenses row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Monthly Income
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CharcoalSurfaceHigh,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = null,
                            tint = ElectricTeal,
                            modifier = Modifier.size(16.dp)
                        )
                        Column {
                            Text(
                                text = "Masuk/Bulan",
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                            Text(
                                text = FormatUtils.formatRupiah(finance.monthlyIncome),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElectricTeal
                            )
                        }
                    }
                }

                // Monthly Expense
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CharcoalSurfaceHigh,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = null,
                            tint = RubyRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Column {
                            Text(
                                text = "Keluar/Bulan",
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                            Text(
                                text = FormatUtils.formatRupiah(finance.monthlyExpense),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = RubyRed
                            )
                        }
                    }
                }
            }

            // Accordion toggle for assets & debts
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { isExpanded = !isExpanded }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isExpanded) "Sembunyikan Rincian Aset & Utang" else "Lihat Rincian Aset & Utang",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Daftar Kepemilikan Aset:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AmberAccent
                    )
                    if (finance.assets.isEmpty()) {
                        Text(
                            text = "Belum memiliki aset bernilai tinggi.",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    } else {
                        finance.assets.forEach { asset ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CharcoalCardVariant, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = asset.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "Kategori: ${asset.category}",
                                        fontSize = 10.sp,
                                        color = TextMuted
                                    )
                                }
                                Text(
                                    text = FormatUtils.formatRupiah(asset.value),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ElectricTeal
                                )
                            }
                        }
                    }

                    if (finance.debts.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Daftar Kewajiban & Utang:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = RubyRed
                        )
                        finance.debts.forEach { debt ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CharcoalCardVariant, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = debt.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "Cicilan: ${FormatUtils.formatRupiah(debt.monthlyPayment)}/bln",
                                        fontSize = 10.sp,
                                        color = TextMuted
                                    )
                                }
                                Text(
                                    text = FormatUtils.formatRupiah(debt.totalAmount),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RubyRed
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Riwayat Arus Kas & Transaksi:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = ElectricTeal
                    )
                    if (finance.transactions.isEmpty()) {
                        Text(
                            text = "Belum ada transaksi arus kas tercatat.",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    } else {
                        finance.transactions.take(8).forEach { tx ->
                            val isInflow = tx.amount >= 0
                            val typeColor = when (tx.type) {
                                com.example.model.TransactionType.JOB_INCOME -> ElectricTeal
                                com.example.model.TransactionType.BUSINESS_INCOME -> ElectricTeal
                                com.example.model.TransactionType.ALLOWANCE_GIFT -> AmberAccent
                                com.example.model.TransactionType.BUSINESS_CAPITAL -> AmberAccent
                                com.example.model.TransactionType.PERSONAL_EXPENSE -> RubyRed
                                com.example.model.TransactionType.OPERATING_COST -> RubyRed
                                com.example.model.TransactionType.SHOP_PURCHASE -> ElectricTeal
                                else -> TextSecondary
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CharcoalCardVariant, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 10.dp, vertical = 7.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(3.dp),
                                            color = typeColor.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = tx.type.label,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = typeColor,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                        Text(
                                            text = "Usia ${tx.age}",
                                            fontSize = 9.sp,
                                            color = TextMuted
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = tx.description,
                                        fontSize = 11.sp,
                                        color = TextPrimary,
                                        maxLines = 2
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${if (isInflow && tx.amount > 0) "+" else ""}${FormatUtils.formatRupiah(tx.amount)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isInflow) ElectricTeal else RubyRed
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
