package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActionAiResult
import com.example.ui.theme.*
import com.example.util.FormatUtils

@Composable
fun FreeActionAiPanel(
    inputText: String,
    onInputChange: (String) -> Unit,
    onSubmitAction: (String?) -> Unit,
    isProcessing: Boolean,
    lastResult: ActionAiResult?,
    onDismissResult: () -> Unit,
    modifier: Modifier = Modifier
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    val suggestionPrompts = listOf(
        "gw mau belajar pemrograman.",
        "gw mau melamar kerja di perusahaan teknologi.",
        "gw mau buka kedai kopi dengan modal 10 juta.",
        "gw mau memperbaiki hubungan dengan ayah gw.",
        "gw mau pindah kota dan memulai hidup baru.",
        "gw mau mulai rajin olahraga lari pagi.",
        "gw mau ngajak pasangan kencan romantis."
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(
                listOf(ElectricTeal.copy(alpha = 0.6f), CharcoalCard)
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Panel Title with AI indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(TealGlow),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = ElectricTeal,
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    Text(
                        text = "WHAT WILL YOU DO?",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        letterSpacing = 1.sp,
                        color = ElectricTeal
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = CharcoalSurfaceHigh
                ) {
                    Text(
                        text = "FREE ACTION AI",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberAccent,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = "Ketik tindakan apapun dalam bahasa Indonesia sehari-hari. AI simulator akan menafsirkan hasilnya secara realistis.",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            // Quick suggestion chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(suggestionPrompts) { prompt ->
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = CharcoalCardVariant,
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.horizontalGradient(listOf(CharcoalOutline, CharcoalSurfaceHigh))
                        ),
                        modifier = Modifier.clickable {
                            onInputChange(prompt)
                        }
                    ) {
                        Text(
                            text = prompt,
                            fontSize = 11.sp,
                            color = TextPrimary,
                            maxLines = 1,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Input field & Execute button
            OutlinedTextField(
                value = inputText,
                onValueChange = onInputChange,
                placeholder = {
                    Text(
                        text = "Contoh: gw mau buka kedai kopi dengan modal 10 juta...",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_free_action"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CharcoalCardVariant,
                    unfocusedContainerColor = CharcoalCardVariant,
                    focusedBorderColor = ElectricTeal,
                    unfocusedBorderColor = CharcoalOutline,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        keyboardController?.hide()
                        onSubmitAction(null)
                    }
                ),
                maxLines = 3,
                trailingIcon = {
                    if (isProcessing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = ElectricTeal,
                            strokeWidth = 2.dp
                        )
                    } else {
                        IconButton(
                            onClick = {
                                keyboardController?.hide()
                                onSubmitAction(null)
                            },
                            enabled = inputText.isNotBlank(),
                            modifier = Modifier.testTag("btn_submit_action")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Kirim Tindakan",
                                tint = if (inputText.isNotBlank()) ElectricTeal else TextMuted
                            )
                        }
                    }
                }
            )

            // Button Action
            Button(
                onClick = {
                    keyboardController?.hide()
                    onSubmitAction(null)
                },
                enabled = inputText.isNotBlank() && !isProcessing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("btn_execute_action"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricTeal,
                    contentColor = CharcoalBackground,
                    disabledContainerColor = CharcoalSurfaceHigh,
                    disabledContentColor = TextMuted
                )
            ) {
                if (isProcessing) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = CharcoalBackground,
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = "AI Sedang Mensimulasikan Konsekuensi...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "EKSEKUSI TINDAKAN",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            // Narrative Result Card
            AnimatedVisibility(visible = lastResult != null) {
                lastResult?.let { result ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CharcoalCardVariant),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.verticalGradient(
                                if (result.actionValid) listOf(ElectricTeal, TealDark)
                                else listOf(AmberAccent, AmberDark)
                            )
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (result.actionValid) TealGlow else AmberGlow
                                    ) {
                                        Text(
                                            text = if (result.actionValid) "BERHASIL DILAKUKAN" else "KENDALA REALISTIS",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (result.actionValid) ElectricTeal else AmberAccent,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }

                                    if (result.isLocalSimulation) {
                                        Text(
                                            text = "[Simulasi Lokal]",
                                            fontSize = 10.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = onDismissResult,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Tutup",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            // Narrative text
                            Text(
                                text = result.narrative,
                                fontSize = 13.sp,
                                color = TextPrimary,
                                lineHeight = 18.sp
                            )

                            // Obstacle reason if any
                            result.obstacleReason?.let { reason ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = RubyRed.copy(alpha = 0.15f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Alasan: $reason",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = RubyRed,
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                            }

                            // Stat changes chips
                            if (result.statChanges.isNotEmpty() || result.financialChanges.cashDelta != 0L || result.financialChanges.newAsset != null) {
                                HorizontalDivider(color = CharcoalOutline.copy(alpha = 0.5f))
                                Text(
                                    text = "Dampak Statistik & Keuangan:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextSecondary
                                )

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    result.statChanges.forEach { (statName, delta) ->
                                        if (delta != 0) {
                                            val isPositive = delta > 0
                                            val statColor = when (statName) {
                                                "health" -> HealthColor
                                                "happiness" -> HappinessColor
                                                "intellect" -> IntellectColor
                                                "reputation" -> ReputationColor
                                                "energy" -> EnergyColor
                                                else -> ElectricTeal
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = CharcoalSurfaceHigh
                                            ) {
                                                Text(
                                                    text = "${statName.replaceFirstChar { it.uppercase() }} ${if (isPositive) "+$delta" else "$delta"}",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = statColor,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                )
                                            }
                                        }
                                    }

                                    if (result.financialChanges.cashDelta != 0L) {
                                        val cDelta = result.financialChanges.cashDelta
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = CharcoalSurfaceHigh
                                        ) {
                                            Text(
                                                text = "${if (cDelta > 0) "+" else ""}${FormatUtils.formatRupiah(cDelta)}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (cDelta > 0) ElectricTeal else RubyRed,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
