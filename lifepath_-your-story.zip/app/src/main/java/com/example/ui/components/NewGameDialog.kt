package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.PersonalityCatalog
import com.example.model.AvatarAppearance
import com.example.model.Gender
import com.example.ui.theme.*

@Composable
fun NewGameDialog(
    onDismiss: () -> Unit,
    onCreateCharacter: (
        name: String,
        gender: Gender,
        startAge: Int,
        birthCity: String,
        background: String,
        avatar: AvatarAppearance,
        personalityTraits: List<String>
    ) -> Unit
) {
    var nameInput by remember { mutableStateOf("Rian Gunawan") }
    var selectedGender by remember { mutableStateOf(Gender.MALE) }
    var selectedAge by remember { mutableStateOf(18) }
    var selectedCity by remember { mutableStateOf("Jakarta") }
    var selectedBackground by remember { mutableStateOf("Keluarga Menengah Pekerja Keras") }
    var selectedTraits by remember { mutableStateOf(listOf("Ambisius", "Kreatif")) }
    var avatarAppearance by remember { mutableStateOf(AvatarAppearance()) }

    val ageOptions = listOf(
        0 to "Bayi (0 Thn)",
        6 to "Anak SD (6 Thn)",
        15 to "Remaja (15 Thn)",
        18 to "Lulus SMA (18 Thn)",
        25 to "Dewasa (25 Thn)"
    )

    val cityOptions = listOf("Jakarta", "Bandung", "Surabaya", "Yogyakarta", "Medan", "Denpasar", "Makassar")
    val backgroundOptions = listOf(
        "Keluarga Menengah Pekerja Keras",
        "Keluarga Pebisnis Mandiri",
        "Keluarga Seniman & Kreator",
        "Keluarga Sederhana Penuh Kasih"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 24.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.verticalGradient(listOf(ElectricTeal, CharcoalOutline))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = null,
                            tint = ElectricTeal,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "BUAT KARAKTER BARU",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 0.5.sp,
                            color = TextPrimary
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Tutup",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                HorizontalDivider(color = CharcoalOutline)

                // Name field
                Text(
                    text = "Nama Lengkap Karakter",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_new_character_name"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CharcoalCardVariant,
                        unfocusedContainerColor = CharcoalCardVariant,
                        focusedBorderColor = ElectricTeal,
                        unfocusedBorderColor = CharcoalOutline,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                // Gender choices
                Text(
                    text = "Jenis Kelamin",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Gender.values().forEach { g ->
                        val isSelected = selectedGender == g
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) TealGlow else CharcoalCardVariant,
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    if (isSelected) listOf(ElectricTeal, TealDark) else listOf(CharcoalOutline, CharcoalOutline)
                                )
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedGender = g }
                        ) {
                            Text(
                                text = g.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) ElectricTeal else TextSecondary,
                                modifier = Modifier
                                    .padding(vertical = 8.dp)
                                    .wrapContentWidth(Alignment.CenterHorizontally)
                            )
                        }
                    }
                }

                // Starting Age choices
                Text(
                    text = "Pilih Usia Awal Memulai Hidup",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ageOptions) { (age, label) ->
                        val isSelected = selectedAge == age
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) AmberGlow else CharcoalCardVariant,
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    if (isSelected) listOf(AmberAccent, AmberDark) else listOf(CharcoalOutline, CharcoalOutline)
                                )
                            ),
                            modifier = Modifier.clickable { selectedAge = age }
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) AmberAccent else TextSecondary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                // City choices
                Text(
                    text = "Kota Kelahiran",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(cityOptions) { city ->
                        val isSelected = selectedCity == city
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) TealGlow else CharcoalCardVariant,
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    if (isSelected) listOf(ElectricTeal, TealDark) else listOf(CharcoalOutline, CharcoalOutline)
                                )
                            ),
                            modifier = Modifier.clickable { selectedCity = city }
                        ) {
                            Text(
                                text = city,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) ElectricTeal else TextSecondary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }
                    }
                }

                // Background trait choices
                Text(
                    text = "Latar Belakang Keluarga",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    backgroundOptions.forEach { bg ->
                        val isSelected = selectedBackground == bg
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) CharcoalSurfaceHigh else CharcoalCardVariant,
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    if (isSelected) listOf(ElectricTeal, TealDark) else listOf(CharcoalOutline, CharcoalOutline)
                                )
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedBackground = bg }
                        ) {
                            Text(
                                text = bg,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) ElectricTeal else TextPrimary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                // Personality Traits Selection (Max 3)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Sifat Karakter (Maks. 3)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )
                    Text(
                        text = "${selectedTraits.size}/3 Dipilih",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberAccent
                    )
                }

                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    PersonalityCatalog.availableTraits.forEach { trait ->
                        val isSelected = selectedTraits.contains(trait.name)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) AmberGlow else CharcoalCardVariant,
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    if (isSelected) listOf(AmberAccent, AmberDark) else listOf(CharcoalOutline, CharcoalOutline)
                                )
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (isSelected) {
                                        if (selectedTraits.size > 1) {
                                            selectedTraits = selectedTraits - trait.name
                                        }
                                    } else {
                                        if (selectedTraits.size < 3) {
                                            selectedTraits = selectedTraits + trait.name
                                        }
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = trait.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) AmberAccent else TextPrimary
                                    )
                                    Text(
                                        text = trait.effectDescription,
                                        fontSize = 10.sp,
                                        color = TextMuted
                                    )
                                }
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = null,
                                        tint = AmberAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Create Character Button
                Button(
                    onClick = {
                        val validName = if (nameInput.isBlank()) "Aditya Pratama" else nameInput.trim()
                        onCreateCharacter(
                            validName,
                            selectedGender,
                            selectedAge,
                            selectedCity,
                            selectedBackground,
                            avatarAppearance,
                            selectedTraits
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_confirm_create_character"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricTeal,
                        contentColor = CharcoalBackground
                    )
                ) {
                    Text(
                        text = "MULAI KISAH HIDUP",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}
