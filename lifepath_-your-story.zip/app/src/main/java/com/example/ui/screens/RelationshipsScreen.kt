package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Relationship
import com.example.ui.theme.*

@Composable
fun RelationshipsScreen(
    relationships: List<Relationship>,
    onInteract: (relId: String, actionType: String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.People,
                        contentDescription = null,
                        tint = AmberAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "LINGKARAN HUBUNGAN",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 0.5.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "Keluarga, sahabat, pasangan, dan relasi di sekitarmu.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            if (relationships.isEmpty()) {
                item {
                    Text(
                        text = "Belum memiliki relasi sosial yang tercatat.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            } else {
                items(relationships) { rel ->
                    RelationshipCardItem(
                        relationship = rel,
                        onInteract = onInteract
                    )
                }
            }
        }
    }
}

@Composable
private fun RelationshipCardItem(
    relationship: Relationship,
    onInteract: (relId: String, actionType: String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(listOf(CharcoalOutline, CharcoalCard))
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Avatar icon
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(CharcoalCardVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = AmberAccent,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = relationship.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CharcoalSurfaceHigh
                        ) {
                            Text(
                                text = "${relationship.relationType.label} • ${relationship.age} Thn",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElectricTeal,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "Kepribadian: ${relationship.personality}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            // Closeness Progress Bar
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Kedekatan Emosional", fontSize = 10.sp, color = TextMuted)
                    Text(
                        text = "${relationship.closeness}%",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (relationship.closeness >= 70) ElectricTeal else AmberAccent
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                LinearProgressIndicator(
                    progress = { relationship.closeness / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (relationship.closeness >= 70) ElectricTeal else AmberAccent,
                    trackColor = CharcoalSurfaceHigh
                )
            }

            // Status message
            if (relationship.statusDescription.isNotBlank()) {
                Text(
                    text = "Status: \"${relationship.statusDescription}\"",
                    fontSize = 11.sp,
                    color = TextPrimary,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }

            HorizontalDivider(color = CharcoalOutline.copy(alpha = 0.5f))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onInteract(relationship.id, "CHAT") },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("btn_rel_chat_${relationship.id}"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricTeal)
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Ngobrol", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { onInteract(relationship.id, "GIFT") },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("btn_rel_gift_${relationship.id}"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AmberAccent)
                ) {
                    Icon(imageVector = Icons.Default.CardGiftcard, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Beri Kado", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { onInteract(relationship.id, "RESOLVE") },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("btn_rel_resolve_${relationship.id}"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
                ) {
                    Icon(imageVector = Icons.Default.Handshake, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Rukunkan", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
