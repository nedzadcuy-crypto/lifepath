package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActionAiResult
import com.example.model.CharacterProfile
import com.example.model.FinancialState
import com.example.model.LifeStats
import com.example.model.TimelineEvent
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    profile: CharacterProfile,
    stats: LifeStats,
    finance: FinancialState,
    timeline: List<TimelineEvent>,
    inputText: String,
    onInputChange: (String) -> Unit,
    onSubmitAction: (String?) -> Unit,
    isProcessingAction: Boolean,
    lastActionResult: ActionAiResult?,
    onDismissActionResult: () -> Unit,
    onAdvanceOneYear: () -> Unit,
    onOpenStudio: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Character Identity Card
            item {
                CharacterCard(
                    profile = profile,
                    onOpenStudio = onOpenStudio
                )
            }

            // 2. Life Stats Grid (0 - 100)
            item {
                StatsGrid(stats = stats)
            }

            // 3. Finance & Assets Card
            item {
                FinanceCard(finance = finance)
            }

            // 4. Free Action AI Panel ("WHAT WILL YOU DO?")
            item {
                FreeActionAiPanel(
                    inputText = inputText,
                    onInputChange = onInputChange,
                    onSubmitAction = onSubmitAction,
                    isProcessing = isProcessingAction,
                    lastResult = lastActionResult,
                    onDismissResult = onDismissActionResult
                )
            }

            // 5. LANJUTKAN WAKTU (+1 TAHUN) Primary Button
            item {
                Button(
                    onClick = onAdvanceOneYear,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_advance_time"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberAccent,
                        contentColor = CharcoalBackground
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "LANJUTKAN WAKTU (+1 TAHUN)",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // 6. Timeline View
            item {
                TimelineView(events = timeline)
            }
        }
    }
}
