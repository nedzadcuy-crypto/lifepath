package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LifePathColorScheme = darkColorScheme(
    primary = ElectricTeal,
    onPrimary = CharcoalBackground,
    primaryContainer = TealDark,
    onPrimaryContainer = Color.White,
    secondary = AmberAccent,
    onSecondary = CharcoalBackground,
    secondaryContainer = AmberDark,
    onSecondaryContainer = Color.White,
    tertiary = VioletAccent,
    onTertiary = Color.White,
    background = CharcoalBackground,
    onBackground = TextPrimary,
    surface = CharcoalCard,
    onSurface = TextPrimary,
    surfaceVariant = CharcoalCardVariant,
    onSurfaceVariant = TextSecondary,
    outline = CharcoalOutline,
    outlineVariant = CharcoalSurfaceHigh,
    error = RubyRed,
    onError = Color.White
)

@Composable
fun LifePathTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LifePathColorScheme,
        typography = Typography,
        content = content
    )
}

// Keep backward compatibility name if referenced
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    LifePathTheme(content = content)
}
