package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EventCategory
import com.example.model.TimelineEvent
import com.example.ui.theme.*

@Composable
fun TimelineView(
    events: List<TimelineEvent>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(
                listOf(CharcoalOutline, CharcoalCard)
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = AmberAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "TIMELINE KEHIDUPAN",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp,
                        color = TextSecondary
                    )
                }

                Text(
                    text = "${events.size} Peristiwa",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            if (events.isEmpty()) {
                Text(
                    text = "Belum ada catatan peristiwa kehidupan.",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    events.take(15).forEach { event ->
                        TimelineItemRow(event = event)
                    }
                }
            }
        }
    }
}

@Composable
private fun TimelineItemRow(event: TimelineEvent) {
    val categoryColor = when (event.category) {
        EventCategory.EDUCATION -> IntellectColor
        EventCategory.CAREER -> AmberAccent
        EventCategory.FINANCE -> ElectricTeal
        EventCategory.HEALTH -> HealthColor
        EventCategory.RELATIONSHIP -> ReputationColor
        EventCategory.MILESTONE -> VioletAccent
        EventCategory.GENERAL -> TextSecondary
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Age indicator badge
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = CharcoalCardVariant,
            modifier = Modifier.widthIn(min = 52.dp)
        ) {
            Text(
                text = "Usia ${event.age}",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = ElectricTeal,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
            )
        }

        // Connector dot & content
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = categoryColor.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = event.category.label,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = categoryColor,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                }

                Text(
                    text = "${event.year}",
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = event.text,
                fontSize = 12.sp,
                color = TextPrimary,
                lineHeight = 16.sp
            )
        }
    }
}
