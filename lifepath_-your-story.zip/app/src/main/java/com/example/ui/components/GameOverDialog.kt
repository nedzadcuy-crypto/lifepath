package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.CharacterProfile
import com.example.model.FinancialState
import com.example.model.GameAchievement
import com.example.ui.theme.*
import com.example.util.FormatUtils

@Composable
fun GameOverDialog(
    profile: CharacterProfile,
    finance: FinancialState,
    achievements: List<GameAchievement>,
    onRestart: () -> Unit
) {
    Dialog(onDismissRequest = { /* Modal lock */ }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.verticalGradient(listOf(RubyRed, CharcoalOutline))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.HourglassBottom,
                    contentDescription = null,
                    tint = RubyRed,
                    modifier = Modifier.size(36.dp)
                )

                Text(
                    text = "AKHIR SEBUAH KISAH",
                    fontWeight = FontWeight.Black,
                    fontSize = 17.sp,
                    letterSpacing = 1.sp,
                    color = RubyRed
                )

                Text(
                    text = "${profile.name}\n(${profile.birthYear} - ${profile.currentYear})\nUsia ${profile.age} Tahun",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CharcoalCardVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Penyebab Berpulang:\n${profile.causeOfDeath ?: "Meninggal dunia karena faktor usia."}",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                HorizontalDivider(color = CharcoalOutline)

                // Stats summary
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Total Kekayaan", fontSize = 10.sp, color = TextMuted)
                        Text(
                            text = FormatUtils.formatRupiah(finance.netWorth),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElectricTeal
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Pencapaian Hidup", fontSize = 10.sp, color = TextMuted)
                        val unlocked = achievements.count { it.unlockedAtAge != null }
                        Text(
                            text = "$unlocked / ${achievements.size}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AmberAccent
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Pekerjaan Terakhir", fontSize = 10.sp, color = TextMuted)
                        Text(
                            text = profile.occupation,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Button(
                    onClick = onRestart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberAccent,
                        contentColor = CharcoalBackground
                    )
                ) {
                    Text(
                        text = "MULAI KEHIDUPAN BARU",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
