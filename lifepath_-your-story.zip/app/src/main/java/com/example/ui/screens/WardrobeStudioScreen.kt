package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.WardrobeCatalog
import com.example.model.AvatarAppearance
import com.example.model.ClothingCategory
import com.example.model.FinancialState
import com.example.model.ShopClothingItem
import com.example.ui.components.Avatar2DView
import com.example.ui.theme.*
import com.example.util.FormatUtils

enum class StudioSubTab(val label: String) {
    STUDIO("Studio Karakter"),
    SHOP("Boutique Pakaian")
}

@Composable
fun WardrobeStudioScreen(
    currentAppearance: AvatarAppearance,
    ownedClothingIds: List<String>,
    finance: FinancialState,
    onSaveAppearance: (AvatarAppearance) -> Unit,
    onPurchaseItem: (ShopClothingItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableStateOf(StudioSubTab.STUDIO) }
    var tempAppearance by remember(currentAppearance) { mutableStateOf(currentAppearance) }
    var selectedShopCategory by remember { mutableStateOf<ClothingCategory?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Live 2D Avatar Preview Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.verticalGradient(listOf(ElectricTeal, CharcoalOutline))
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "AVATAR 2D LIVE STUDIO",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                letterSpacing = 1.sp,
                                color = ElectricTeal
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AmberGlow
                            ) {
                                Text(
                                    text = "Kas: ${FormatUtils.formatRupiah(finance.cash)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberAccent,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        // Central Live 2D Layered Avatar
                        Avatar2DView(
                            appearance = tempAppearance,
                            size = 190.dp
                        )

                        // SubTab Selector
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(CharcoalCardVariant)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { activeSubTab = StudioSubTab.STUDIO },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (activeSubTab == StudioSubTab.STUDIO) ElectricTeal else Color.Transparent,
                                    contentColor = if (activeSubTab == StudioSubTab.STUDIO) CharcoalBackground else TextSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("tab_sub_studio")
                            ) {
                                Icon(imageVector = Icons.Default.Face, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Studio Avatar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { activeSubTab = StudioSubTab.SHOP },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (activeSubTab == StudioSubTab.SHOP) AmberAccent else Color.Transparent,
                                    contentColor = if (activeSubTab == StudioSubTab.SHOP) CharcoalBackground else TextSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("tab_sub_shop")
                            ) {
                                Icon(imageVector = Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Boutique Shop", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // STUDIO TAB CONTENT
            if (activeSubTab == StudioSubTab.STUDIO) {
                item {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Skin Tone Selector
                        CustomizationSection(title = "Warna Kulit") {
                            val skinTones = listOf("LIGHT" to "Terang", "MEDIUM" to "Kuning Langsat", "TAN" to "Sawo Matang", "WARM" to "Hangat", "DARK" to "Eksotis")
                            items(skinTones) { (key, label) ->
                                OptionChip(
                                    label = label,
                                    isSelected = tempAppearance.skinTone == key,
                                    onClick = { tempAppearance = tempAppearance.copy(skinTone = key) }
                                )
                            }
                        }

                        // Hair Style Selector
                        CustomizationSection(title = "Gaya Rambut") {
                            val hairStyles = listOf(
                                "SHORT_CURLY" to "Keriting Pendek",
                                "SLICK_BACK" to "Slick Back",
                                "BOB" to "Bob Modern",
                                "LONG_WAVY" to "Wavy Panjang",
                                "BUZZ_CUT" to "Buzz Cut",
                                "PONYTAIL" to "Kuncir Kuda"
                            )
                            items(hairStyles) { (key, label) ->
                                OptionChip(
                                    label = label,
                                    isSelected = tempAppearance.hairStyle == key,
                                    onClick = { tempAppearance = tempAppearance.copy(hairStyle = key) }
                                )
                            }
                        }

                        // Hair Color Selector
                        CustomizationSection(title = "Warna Rambut") {
                            val hairColors = listOf(
                                "BLACK" to "Hitam Alami",
                                "BROWN" to "Cokelat Tua",
                                "BLONDE" to "Pirang Emas",
                                "ELECTRIC_TEAL" to "Teal Neon",
                                "AMBER" to "Amber Merona",
                                "SILVER" to "Perak Platina"
                            )
                            items(hairColors) { (key, label) ->
                                OptionChip(
                                    label = label,
                                    isSelected = tempAppearance.hairColor == key,
                                    onClick = { tempAppearance = tempAppearance.copy(hairColor = key) }
                                )
                            }
                        }

                        // Top Clothing Style
                        CustomizationSection(title = "Model Atasan") {
                            val tops = listOf(
                                "T_SHIRT" to "Kaos Santai",
                                "HOODIE" to "Hoodie Urban",
                                "KEMEJA" to "Kemeja Formal",
                                "BATIK" to "Batik Sutra",
                                "JAKET_KULIT" to "Jaket Kulit",
                                "BLAZER" to "Jas Blazer"
                            )
                            items(tops) { (key, label) ->
                                OptionChip(
                                    label = label,
                                    isSelected = tempAppearance.topStyle == key,
                                    onClick = { tempAppearance = tempAppearance.copy(topStyle = key) }
                                )
                            }
                        }

                        // Top Clothing Color
                        CustomizationSection(title = "Warna Atasan") {
                            val topColors = listOf(
                                "ELECTRIC_TEAL" to "Electric Teal",
                                "CHARCOAL" to "Charcoal Dark",
                                "WHITE" to "Putih Bersih",
                                "NAVY" to "Navy Blue",
                                "AMBER" to "Amber Gold",
                                "RUBY_RED" to "Merah Ruby"
                            )
                            items(topColors) { (key, label) ->
                                OptionChip(
                                    label = label,
                                    isSelected = tempAppearance.topColor == key,
                                    onClick = { tempAppearance = tempAppearance.copy(topColor = key) }
                                )
                            }
                        }

                        // Bottom Clothing Style
                        CustomizationSection(title = "Model Bawahan") {
                            val bottoms = listOf(
                                "JEANS" to "Jeans Denim",
                                "CHINOS" to "Chinos Slim",
                                "CELANA_BAHAN" to "Celana Bahan",
                                "JOGGER" to "Jogger Street",
                                "ROK_MIDI" to "Rok Midi"
                            )
                            items(bottoms) { (key, label) ->
                                OptionChip(
                                    label = label,
                                    isSelected = tempAppearance.bottomStyle == key,
                                    onClick = { tempAppearance = tempAppearance.copy(bottomStyle = key) }
                                )
                            }
                        }

                        // Shoes Style
                        CustomizationSection(title = "Sepatu") {
                            val shoes = listOf(
                                "SNEAKERS" to "Sneakers Kasual",
                                "LEATHER_SHOES" to "Pantofel Kulit",
                                "BOOTS" to "Chelsea Boots",
                                "SLIP_ON" to "Slip-on Santai"
                            )
                            items(shoes) { (key, label) ->
                                OptionChip(
                                    label = label,
                                    isSelected = tempAppearance.shoesStyle == key,
                                    onClick = { tempAppearance = tempAppearance.copy(shoesStyle = key) }
                                )
                            }
                        }

                        // Accessories
                        CustomizationSection(title = "Aksesori") {
                            val accessories = listOf(
                                "NONE" to "Tanpa Aksesori",
                                "KACAMATA_MODERN" to "Kacamata Modern",
                                "TOPI_BEANIE" to "Topi Beanie",
                                "KALUNG_EMAS" to "Kalung Emas",
                                "JAM_TANGAN" to "Jam Tangan Mewah"
                            )
                            items(accessories) { (key, label) ->
                                OptionChip(
                                    label = label,
                                    isSelected = tempAppearance.accessory == key,
                                    onClick = { tempAppearance = tempAppearance.copy(accessory = key) }
                                )
                            }
                        }

                        // Save Appearance Button
                        Button(
                            onClick = { onSaveAppearance(tempAppearance) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_save_appearance"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricTeal,
                                contentColor = CharcoalBackground
                            )
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "SIMPAN PENAMPILAN AVATAR", fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                    }
                }
            }

            // SHOP TAB CONTENT
            if (activeSubTab == StudioSubTab.SHOP) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "KOLEKSI BUTIK TRENDY",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )

                        // Category Filter Chips
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item {
                                FilterChip(
                                    selected = selectedShopCategory == null,
                                    onClick = { selectedShopCategory = null },
                                    label = { Text("Semua", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AmberAccent,
                                        selectedLabelColor = CharcoalBackground
                                    )
                                )
                            }
                            items(ClothingCategory.values()) { cat ->
                                FilterChip(
                                    selected = selectedShopCategory == cat,
                                    onClick = { selectedShopCategory = cat },
                                    label = { Text(cat.label, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AmberAccent,
                                        selectedLabelColor = CharcoalBackground
                                    )
                                )
                            }
                        }
                    }
                }

                val filteredItems = WardrobeCatalog.shopItems.filter {
                    selectedShopCategory == null || it.category == selectedShopCategory
                }

                items(filteredItems) { item ->
                    val isOwned = ownedClothingIds.contains(item.id)
                    val canAfford = finance.cash >= item.price

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.verticalGradient(
                                if (isOwned) listOf(ElectricTeal, TealDark) else listOf(CharcoalOutline, CharcoalCard)
                            )
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isOwned) TealGlow else CharcoalSurfaceHigh),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Checkroom,
                                    contentDescription = null,
                                    tint = if (isOwned) ElectricTeal else AmberAccent,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = TextPrimary
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = CharcoalSurfaceHigh
                                    ) {
                                        Text(
                                            text = "+${item.reputationBonus} Rep",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = ReputationColor,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = item.description,
                                    fontSize = 11.sp,
                                    color = TextMuted,
                                    lineHeight = 14.sp
                                )

                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = FormatUtils.formatRupiah(item.price),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = AmberAccent
                                )
                            }

                            if (isOwned) {
                                Button(
                                    onClick = {
                                        // Equip immediately
                                        tempAppearance = when (item.category) {
                                            ClothingCategory.TOP -> tempAppearance.copy(topStyle = item.styleKey, topColor = item.colorKey)
                                            ClothingCategory.BOTTOM -> tempAppearance.copy(bottomStyle = item.styleKey, bottomColor = item.colorKey)
                                            ClothingCategory.SHOES -> tempAppearance.copy(shoesStyle = item.styleKey, shoesColor = item.colorKey)
                                            ClothingCategory.ACCESSORY -> tempAppearance.copy(accessory = item.styleKey)
                                            ClothingCategory.HAIR -> tempAppearance.copy(hairStyle = item.styleKey, hairColor = item.colorKey)
                                        }
                                        onSaveAppearance(tempAppearance)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = ElectricTeal, contentColor = CharcoalBackground)
                                ) {
                                    Text(text = "Pakai", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Button(
                                    onClick = { onPurchaseItem(item) },
                                    enabled = canAfford,
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AmberAccent,
                                        contentColor = CharcoalBackground,
                                        disabledContainerColor = CharcoalSurfaceHigh,
                                        disabledContentColor = TextMuted
                                    ),
                                    modifier = Modifier.testTag("btn_buy_item_${item.id}")
                                ) {
                                    Text(text = if (canAfford) "Beli" else "Kurang Kas", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomizationSection(
    title: String,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            content = content
        )
    }
}

@Composable
private fun OptionChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) TealGlow else CharcoalCardVariant,
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
                if (isSelected) listOf(ElectricTeal, TealDark) else listOf(CharcoalOutline, CharcoalOutline)
            )
        ),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) ElectricTeal else TextPrimary,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}
