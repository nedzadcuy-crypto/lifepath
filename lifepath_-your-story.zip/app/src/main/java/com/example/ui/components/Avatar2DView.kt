package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.AvatarAppearance
import com.example.ui.theme.*

@Composable
fun Avatar2DView(
    appearance: AvatarAppearance,
    modifier: Modifier = Modifier,
    size: Dp = 180.dp,
    showBorderGlow: Boolean = true
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.16f))
            .background(
                Brush.radialGradient(
                    listOf(CharcoalSurfaceHigh, CharcoalCard)
                )
            )
            .then(
                if (showBorderGlow) {
                    Modifier.border(
                        width = 2.dp,
                        brush = Brush.linearGradient(listOf(ElectricTeal, AmberAccent)),
                        shape = RoundedCornerShape(size * 0.16f)
                    )
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height

            val skinColor = resolveSkinColor(appearance.skinTone)
            val hairColor = resolveHairColor(appearance.hairColor)
            val topColor = resolveTopColor(appearance.topColor)
            val bottomColor = resolveBottomColor(appearance.bottomColor)
            val shoesColor = resolveShoesColor(appearance.shoesColor)

            // 1. Draw subtle background glow
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(ElectricTeal.copy(alpha = 0.18f), Color.Transparent),
                    center = Offset(w * 0.5f, h * 0.45f),
                    radius = w * 0.45f
                )
            )

            // 2. Draw Back Hair Layer (for long hair styles)
            if (appearance.hairStyle == "LONG_WAVY" || appearance.hairStyle == "PONYTAIL") {
                drawBackHair(w, h, appearance.hairStyle, hairColor)
            }

            // 3. Draw Legs & Shoes
            drawLegsAndShoes(w, h, bottomColor, shoesColor, appearance.bottomStyle, appearance.shoesStyle)

            // 4. Draw Arms & Neck Body Base
            drawBodyBase(w, h, skinColor)

            // 5. Draw Top Clothing
            drawTopClothing(w, h, topColor, appearance.topStyle)

            // 6. Draw Head & Face
            drawHeadAndFace(w, h, skinColor, hairColor)

            // 7. Draw Front Hair
            drawFrontHair(w, h, appearance.hairStyle, hairColor)

            // 8. Draw Accessories
            drawAccessory(w, h, appearance.accessory)
        }
    }
}

private fun resolveSkinColor(tone: String): Color = when (tone) {
    "LIGHT" -> Color(0xFFFFDFC4)
    "MEDIUM" -> Color(0xFFE8B588)
    "TAN" -> Color(0xFFC68642)
    "WARM" -> Color(0xFF8D5524)
    "DARK" -> Color(0xFF51331B)
    else -> Color(0xFFE8B588)
}

private fun resolveHairColor(colorKey: String): Color = when (colorKey) {
    "BLACK" -> Color(0xFF1E2124)
    "BROWN" -> Color(0xFF5C3D2E)
    "BLONDE" -> Color(0xFFE5C07B)
    "ELECTRIC_TEAL" -> ElectricTeal
    "AMBER" -> AmberAccent
    "SILVER" -> Color(0xFFCBD5E1)
    else -> Color(0xFF1E2124)
}

private fun resolveTopColor(colorKey: String): Color = when (colorKey) {
    "ELECTRIC_TEAL" -> ElectricTeal
    "CHARCOAL" -> Color(0xFF272F3D)
    "WHITE" -> Color(0xFFF1F5F9)
    "NAVY" -> Color(0xFF1E3A8A)
    "AMBER" -> AmberAccent
    "RUBY_RED" -> RubyRed
    else -> ElectricTeal
}

private fun resolveBottomColor(colorKey: String): Color = when (colorKey) {
    "DARK_DENIM" -> Color(0xFF1E293B)
    "BLACK" -> Color(0xFF0F172A)
    "KHAKI" -> Color(0xFFB59F84)
    "GREY" -> Color(0xFF475569)
    else -> Color(0xFF1E293B)
}

private fun resolveShoesColor(colorKey: String): Color = when (colorKey) {
    "WHITE" -> Color(0xFFF8FAFC)
    "BLACK" -> Color(0xFF0F172A)
    "BROWN" -> Color(0xFF6B4226)
    "ELECTRIC_TEAL" -> ElectricTeal
    else -> Color(0xFFF8FAFC)
}

private fun DrawScope.drawBackHair(w: Float, h: Float, style: String, color: Color) {
    if (style == "LONG_WAVY") {
        val path = Path().apply {
            moveTo(w * 0.32f, h * 0.35f)
            cubicTo(w * 0.18f, h * 0.50f, w * 0.22f, h * 0.68f, w * 0.32f, h * 0.72f)
            lineTo(w * 0.68f, h * 0.72f)
            cubicTo(w * 0.78f, h * 0.68f, w * 0.82f, h * 0.50f, w * 0.68f, h * 0.35f)
            close()
        }
        drawPath(path, color)
    } else if (style == "PONYTAIL") {
        drawCircle(
            color = color,
            radius = w * 0.12f,
            center = Offset(w * 0.68f, h * 0.26f)
        )
    }
}

private fun DrawScope.drawLegsAndShoes(
    w: Float,
    h: Float,
    bottomColor: Color,
    shoesColor: Color,
    bottomStyle: String,
    shoesStyle: String
) {
    val legY = h * 0.70f
    val legHeight = h * 0.20f
    val legWidth = w * 0.11f

    if (bottomStyle == "ROK_MIDI") {
        val skirtPath = Path().apply {
            moveTo(w * 0.38f, legY)
            lineTo(w * 0.28f, legY + legHeight * 0.7f)
            lineTo(w * 0.72f, legY + legHeight * 0.7f)
            lineTo(w * 0.62f, legY)
            close()
        }
        drawPath(skirtPath, bottomColor)
    } else {
        // Left Leg
        drawRoundRect(
            color = bottomColor,
            topLeft = Offset(w * 0.36f, legY),
            size = Size(legWidth, legHeight),
            cornerRadius = CornerRadius(6f, 6f)
        )
        // Right Leg
        drawRoundRect(
            color = bottomColor,
            topLeft = Offset(w * 0.53f, legY),
            size = Size(legWidth, legHeight),
            cornerRadius = CornerRadius(6f, 6f)
        )
    }

    // Shoes
    val shoeY = h * 0.88f
    val shoeWidth = w * 0.13f
    val shoeHeight = h * 0.07f

    drawRoundRect(
        color = shoesColor,
        topLeft = Offset(w * 0.34f, shoeY),
        size = Size(shoeWidth, shoeHeight),
        cornerRadius = CornerRadius(8f, 8f)
    )
    drawRoundRect(
        color = shoesColor,
        topLeft = Offset(w * 0.53f, shoeY),
        size = Size(shoeWidth, shoeHeight),
        cornerRadius = CornerRadius(8f, 8f)
    )

    // Shoe sole / highlight
    drawRoundRect(
        color = Color.White.copy(alpha = 0.4f),
        topLeft = Offset(w * 0.34f, shoeY + shoeHeight * 0.7f),
        size = Size(shoeWidth, shoeHeight * 0.3f),
        cornerRadius = CornerRadius(4f, 4f)
    )
    drawRoundRect(
        color = Color.White.copy(alpha = 0.4f),
        topLeft = Offset(w * 0.53f, shoeY + shoeHeight * 0.7f),
        size = Size(shoeWidth, shoeHeight * 0.3f),
        cornerRadius = CornerRadius(4f, 4f)
    )
}

private fun DrawScope.drawBodyBase(w: Float, h: Float, skinColor: Color) {
    // Neck
    drawRect(
        color = skinColor,
        topLeft = Offset(w * 0.45f, h * 0.38f),
        size = Size(w * 0.10f, h * 0.10f)
    )
    // Left Arm / Hand
    drawRoundRect(
        color = skinColor,
        topLeft = Offset(w * 0.22f, h * 0.48f),
        size = Size(w * 0.08f, h * 0.22f),
        cornerRadius = CornerRadius(6f, 6f)
    )
    // Right Arm / Hand
    drawRoundRect(
        color = skinColor,
        topLeft = Offset(w * 0.70f, h * 0.48f),
        size = Size(w * 0.08f, h * 0.22f),
        cornerRadius = CornerRadius(6f, 6f)
    )
}

private fun DrawScope.drawTopClothing(w: Float, h: Float, topColor: Color, style: String) {
    val topX = w * 0.29f
    val topY = h * 0.44f
    val topWidth = w * 0.42f
    val topHeight = h * 0.27f

    // Main Torso
    drawRoundRect(
        color = topColor,
        topLeft = Offset(topX, topY),
        size = Size(topWidth, topHeight),
        cornerRadius = CornerRadius(10f, 10f)
    )

    // Left Sleeve
    drawRoundRect(
        color = topColor,
        topLeft = Offset(w * 0.23f, topY + 2f),
        size = Size(w * 0.10f, h * 0.14f),
        cornerRadius = CornerRadius(8f, 8f)
    )
    // Right Sleeve
    drawRoundRect(
        color = topColor,
        topLeft = Offset(w * 0.67f, topY + 2f),
        size = Size(w * 0.10f, h * 0.14f),
        cornerRadius = CornerRadius(8f, 8f)
    )

    // Style specifics (Collars, Batik patterns, Zippers)
    when (style) {
        "KEMEJA", "BLAZER" -> {
            // White Collar
            val collarPath = Path().apply {
                moveTo(w * 0.42f, topY)
                lineTo(w * 0.50f, topY + h * 0.06f)
                lineTo(w * 0.58f, topY)
                close()
            }
            drawPath(collarPath, Color.White.copy(alpha = 0.9f))
            if (style == "BLAZER") {
                // Gold pocket badge
                drawRect(
                    color = AmberAccent,
                    topLeft = Offset(w * 0.35f, topY + h * 0.08f),
                    size = Size(w * 0.06f, h * 0.015f)
                )
            }
        }
        "BATIK" -> {
            // Stylized gold batik motifs
            drawCircle(
                color = AmberAccent.copy(alpha = 0.5f),
                radius = w * 0.035f,
                center = Offset(w * 0.42f, topY + h * 0.12f)
            )
            drawCircle(
                color = AmberAccent.copy(alpha = 0.5f),
                radius = w * 0.035f,
                center = Offset(w * 0.58f, topY + h * 0.12f)
            )
            drawCircle(
                color = AmberAccent.copy(alpha = 0.5f),
                radius = w * 0.03f,
                center = Offset(w * 0.50f, topY + h * 0.20f)
            )
        }
        "JAKET_KULIT" -> {
            // Diagonal Zipper
            drawLine(
                color = Color.White.copy(alpha = 0.8f),
                start = Offset(w * 0.56f, topY),
                end = Offset(w * 0.44f, topY + topHeight),
                strokeWidth = 3f
            )
        }
        "HOODIE" -> {
            // Hood cords
            drawLine(
                color = Color.White.copy(alpha = 0.7f),
                start = Offset(w * 0.46f, topY + h * 0.02f),
                end = Offset(w * 0.46f, topY + h * 0.10f),
                strokeWidth = 2.5f
            )
            drawLine(
                color = Color.White.copy(alpha = 0.7f),
                start = Offset(w * 0.54f, topY + h * 0.02f),
                end = Offset(w * 0.54f, topY + h * 0.10f),
                strokeWidth = 2.5f
            )
        }
        else -> {
            // Crewneck curve
            drawArc(
                color = Color.Black.copy(alpha = 0.25f),
                startAngle = 0f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(w * 0.43f, topY - h * 0.02f),
                size = Size(w * 0.14f, h * 0.05f),
                style = Stroke(width = 3f)
            )
        }
    }
}

private fun DrawScope.drawHeadAndFace(w: Float, h: Float, skinColor: Color, hairColor: Color) {
    val headCenterX = w * 0.50f
    val headCenterY = h * 0.27f
    val headRadiusX = w * 0.18f
    val headRadiusY = h * 0.17f

    // Head base
    drawOval(
        color = skinColor,
        topLeft = Offset(headCenterX - headRadiusX, headCenterY - headRadiusY),
        size = Size(headRadiusX * 2f, headRadiusY * 2f)
    )

    // Ears
    drawCircle(
        color = skinColor,
        radius = w * 0.035f,
        center = Offset(headCenterX - headRadiusX + 2f, headCenterY)
    )
    drawCircle(
        color = skinColor,
        radius = w * 0.035f,
        center = Offset(headCenterX + headRadiusX - 2f, headCenterY)
    )

    // Eyes
    val eyeY = headCenterY + h * 0.01f
    val leftEyeX = headCenterX - w * 0.07f
    val rightEyeX = headCenterX + w * 0.07f

    // Eye whites
    drawCircle(color = Color.White, radius = w * 0.026f, center = Offset(leftEyeX, eyeY))
    drawCircle(color = Color.White, radius = w * 0.026f, center = Offset(rightEyeX, eyeY))

    // Pupils
    drawCircle(color = Color(0xFF1E293B), radius = w * 0.016f, center = Offset(leftEyeX, eyeY))
    drawCircle(color = Color(0xFF1E293B), radius = w * 0.016f, center = Offset(rightEyeX, eyeY))

    // Catchlights (Sparkle)
    drawCircle(color = Color.White, radius = w * 0.006f, center = Offset(leftEyeX + 2f, eyeY - 2f))
    drawCircle(color = Color.White, radius = w * 0.006f, center = Offset(rightEyeX + 2f, eyeY - 2f))

    // Eyebrows
    drawLine(
        color = hairColor,
        start = Offset(leftEyeX - w * 0.03f, eyeY - h * 0.03f),
        end = Offset(leftEyeX + w * 0.03f, eyeY - h * 0.035f),
        strokeWidth = 3f
    )
    drawLine(
        color = hairColor,
        start = Offset(rightEyeX - w * 0.03f, eyeY - h * 0.035f),
        end = Offset(rightEyeX + w * 0.03f, eyeY - h * 0.03f),
        strokeWidth = 3f
    )

    // Nose
    drawCircle(
        color = skinColor.copy(alpha = 0.7f),
        radius = w * 0.012f,
        center = Offset(headCenterX, headCenterY + h * 0.045f)
    )

    // Smile
    drawArc(
        color = Color(0xFF9E4747),
        startAngle = 10f,
        sweepAngle = 160f,
        useCenter = false,
        topLeft = Offset(headCenterX - w * 0.04f, headCenterY + h * 0.055f),
        size = Size(w * 0.08f, h * 0.04f),
        style = Stroke(width = 3f)
    )

    // Blush
    drawCircle(
        color = Color(0xFFFF8B8B).copy(alpha = 0.35f),
        radius = w * 0.022f,
        center = Offset(leftEyeX - w * 0.02f, eyeY + h * 0.035f)
    )
    drawCircle(
        color = Color(0xFFFF8B8B).copy(alpha = 0.35f),
        radius = w * 0.022f,
        center = Offset(rightEyeX + w * 0.02f, eyeY + h * 0.035f)
    )
}

private fun DrawScope.drawFrontHair(w: Float, h: Float, style: String, color: Color) {
    val headCenterX = w * 0.50f
    val headCenterY = h * 0.27f

    when (style) {
        "BUZZ_CUT" -> {
            drawArc(
                color = color,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = true,
                topLeft = Offset(headCenterX - w * 0.185f, headCenterY - h * 0.175f),
                size = Size(w * 0.37f, h * 0.24f)
            )
        }
        "BOB" -> {
            val path = Path().apply {
                moveTo(headCenterX - w * 0.20f, headCenterY + h * 0.06f)
                cubicTo(headCenterX - w * 0.22f, headCenterY - h * 0.18f, headCenterX + w * 0.22f, headCenterY - h * 0.18f, headCenterX + w * 0.20f, headCenterY + h * 0.06f)
                lineTo(headCenterX + w * 0.15f, headCenterY - h * 0.02f)
                lineTo(headCenterX, headCenterY - h * 0.06f)
                lineTo(headCenterX - w * 0.15f, headCenterY - h * 0.02f)
                close()
            }
            drawPath(path, color)
        }
        "SLICK_BACK" -> {
            val path = Path().apply {
                moveTo(headCenterX - w * 0.19f, headCenterY)
                cubicTo(headCenterX - w * 0.15f, headCenterY - h * 0.21f, headCenterX + w * 0.15f, headCenterY - h * 0.21f, headCenterX + w * 0.19f, headCenterY)
                lineTo(headCenterX + w * 0.10f, headCenterY - h * 0.08f)
                lineTo(headCenterX, headCenterY - h * 0.10f)
                lineTo(headCenterX - w * 0.10f, headCenterY - h * 0.08f)
                close()
            }
            drawPath(path, color)
        }
        "LONG_WAVY", "PONYTAIL" -> {
            val path = Path().apply {
                moveTo(headCenterX - w * 0.19f, headCenterY)
                cubicTo(headCenterX - w * 0.15f, headCenterY - h * 0.20f, headCenterX + w * 0.15f, headCenterY - h * 0.20f, headCenterX + w * 0.19f, headCenterY)
                lineTo(headCenterX + w * 0.12f, headCenterY - h * 0.05f)
                lineTo(headCenterX, headCenterY - h * 0.08f)
                lineTo(headCenterX - w * 0.12f, headCenterY - h * 0.05f)
                close()
            }
            drawPath(path, color)
        }
        else -> {
            // SHORT_CURLY
            drawCircle(color = color, radius = w * 0.09f, center = Offset(headCenterX - w * 0.08f, headCenterY - h * 0.13f))
            drawCircle(color = color, radius = w * 0.10f, center = Offset(headCenterX, headCenterY - h * 0.15f))
            drawCircle(color = color, radius = w * 0.09f, center = Offset(headCenterX + w * 0.08f, headCenterY - h * 0.13f))
            drawCircle(color = color, radius = w * 0.07f, center = Offset(headCenterX - w * 0.15f, headCenterY - h * 0.08f))
            drawCircle(color = color, radius = w * 0.07f, center = Offset(headCenterX + w * 0.15f, headCenterY - h * 0.08f))
        }
    }
}

private fun DrawScope.drawAccessory(w: Float, h: Float, accessory: String) {
    val headCenterX = w * 0.50f
    val headCenterY = h * 0.27f

    when (accessory) {
        "KACAMATA_MODERN" -> {
            val eyeY = headCenterY + h * 0.01f
            val leftEyeX = headCenterX - w * 0.07f
            val rightEyeX = headCenterX + w * 0.07f

            // Frame Left
            drawRoundRect(
                color = ElectricTeal.copy(alpha = 0.25f),
                topLeft = Offset(leftEyeX - w * 0.045f, eyeY - h * 0.025f),
                size = Size(w * 0.09f, h * 0.05f),
                cornerRadius = CornerRadius(4f, 4f)
            )
            drawRoundRect(
                color = Color.Black,
                topLeft = Offset(leftEyeX - w * 0.045f, eyeY - h * 0.025f),
                size = Size(w * 0.09f, h * 0.05f),
                cornerRadius = CornerRadius(4f, 4f),
                style = Stroke(width = 3.5f)
            )

            // Frame Right
            drawRoundRect(
                color = ElectricTeal.copy(alpha = 0.25f),
                topLeft = Offset(rightEyeX - w * 0.045f, eyeY - h * 0.025f),
                size = Size(w * 0.09f, h * 0.05f),
                cornerRadius = CornerRadius(4f, 4f)
            )
            drawRoundRect(
                color = Color.Black,
                topLeft = Offset(rightEyeX - w * 0.045f, eyeY - h * 0.025f),
                size = Size(w * 0.09f, h * 0.05f),
                cornerRadius = CornerRadius(4f, 4f),
                style = Stroke(width = 3.5f)
            )

            // Bridge
            drawLine(
                color = Color.Black,
                start = Offset(leftEyeX + w * 0.045f, eyeY),
                end = Offset(rightEyeX - w * 0.045f, eyeY),
                strokeWidth = 3.5f
            )
        }
        "TOPI_BEANIE" -> {
            drawRoundRect(
                color = AmberAccent,
                topLeft = Offset(headCenterX - w * 0.17f, headCenterY - h * 0.22f),
                size = Size(w * 0.34f, h * 0.12f),
                cornerRadius = CornerRadius(16f, 16f)
            )
            // Beanie Fold
            drawRoundRect(
                color = AmberDark,
                topLeft = Offset(headCenterX - w * 0.18f, headCenterY - h * 0.13f),
                size = Size(w * 0.36f, h * 0.04f),
                cornerRadius = CornerRadius(6f, 6f)
            )
        }
        "KALUNG_EMAS" -> {
            drawArc(
                color = AmberAccent,
                startAngle = 15f,
                sweepAngle = 150f,
                useCenter = false,
                topLeft = Offset(headCenterX - w * 0.06f, h * 0.42f),
                size = Size(w * 0.12f, h * 0.08f),
                style = Stroke(width = 3f)
            )
        }
        "JAM_TANGAN" -> {
            // Watch on right wrist
            drawCircle(
                color = ElectricTeal,
                radius = w * 0.025f,
                center = Offset(w * 0.74f, h * 0.65f)
            )
            drawCircle(
                color = Color.Black,
                radius = w * 0.015f,
                center = Offset(w * 0.74f, h * 0.65f)
            )
        }
    }
}
