package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LIFEPATH Theme Colors
val CharcoalBackground = Color(0xFF101318)
val CharcoalCard = Color(0xFF1B2028)
val CharcoalCardVariant = Color(0xFF242A35)
val CharcoalSurfaceHigh = Color(0xFF2C3442)
val CharcoalOutline = Color(0xFF3B4658)

val ElectricTeal = Color(0xFF55E6C1)
val TealDark = Color(0xFF1B9A7A)
val TealGlow = Color(0x3355E6C1)

val AmberAccent = Color(0xFFFFB830)
val AmberDark = Color(0xFFD98200)
val AmberGlow = Color(0x33FFB830)

val RubyRed = Color(0xFFFF5252)
val VioletAccent = Color(0xFFA55EEA)
val SkyBlue = Color(0xFF45AAF2)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Stat specific colors
val HealthColor = Color(0xFFFF5252)
val HappinessColor = Color(0xFFFFB830)
val IntellectColor = Color(0xFF45AAF2)
val ReputationColor = Color(0xFFA55EEA)
val EnergyColor = Color(0xFF55E6C1)
