package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CareerData
import com.example.model.CharacterProfile
import com.example.model.FinancialState
import com.example.model.JobOpportunity
import com.example.model.LifeStats
import com.example.ui.theme.*
import com.example.util.FormatUtils

@Composable
fun CareerScreen(
    profile: CharacterProfile,
    stats: LifeStats,
    finance: FinancialState,
    onApplyJob: (JobOpportunity) -> Unit,
    onQuickAction: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BusinessCenter,
                        contentDescription = null,
                        tint = ElectricTeal,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "KARIER & PENDIDIKAN",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 0.5.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "Kembangkan profesi, pendidikan, atau bangun imperium bisnismu.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            // Current Status Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.verticalGradient(listOf(ElectricTeal.copy(alpha = 0.5f), CharcoalOutline))
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "STATUS PROFESI SAAT INI",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = profile.occupation,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = ElectricTeal
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = TealGlow
                            ) {
                                Text(
                                    text = "Gaji: ${FormatUtils.formatRupiah(finance.monthlyIncome)}/bln",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ElectricTeal,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Entrepreneurship Prompt Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCardVariant),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.verticalGradient(listOf(AmberAccent.copy(alpha = 0.5f), CharcoalOutline))
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Storefront, contentDescription = null, tint = AmberAccent)
                            Text(
                                text = "Ingin Merintis Bisnis Sendiri?",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberAccent
                            )
                        }

                        Text(
                            text = "Gunakan FREE ACTION AI untuk mengetik ide bisnismu (misal: 'gw mau buka usaha kedai kopi modal 10 juta' atau 'gw mau jualan baju online'). AI akan memeriksa modal kasmu dan menciptakan bisnis nyata!",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 15.sp
                        )

                        Button(
                            onClick = {
                                onQuickAction("gw mau buka usaha kecil dengan modal kas yang gw punya.")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AmberAccent, contentColor = CharcoalBackground),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "RINTIS USAHA VIA AI", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }

            // Job Openings List
            item {
                Text(
                    text = "LOWONGAN PEKERJAAN TERBUKA",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    color = TextSecondary
                )
            }

            items(CareerData.availableJobs) { job ->
                val isCurrentJob = profile.occupation.equals(job.title, ignoreCase = true)
                val meetsAge = profile.age >= job.minAge
                val meetsIntellect = stats.intellect >= job.minIntellect
                val canApply = meetsAge && meetsIntellect && !isCurrentJob

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.verticalGradient(
                            if (isCurrentJob) listOf(ElectricTeal, TealDark) else listOf(CharcoalOutline, CharcoalCard)
                        )
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = job.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${job.company} • Syarat: ${job.educationRequired}",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }

                            Text(
                                text = "${FormatUtils.formatRupiah(job.monthlySalary)}/bln",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElectricTeal
                            )
                        }

                        Text(
                            text = job.description,
                            fontSize = 11.sp,
                            color = TextMuted,
                            lineHeight = 14.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Min Usia: ${job.minAge} thn • Min Otak: ${job.minIntellect}",
                                fontSize = 10.sp,
                                color = if (meetsAge && meetsIntellect) ElectricTeal else RubyRed
                            )

                            if (isCurrentJob) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = TealGlow
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = ElectricTeal, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(text = "Pekerjaan Aktif", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ElectricTeal)
                                    }
                                }
                            } else {
                                Button(
                                    onClick = { onApplyJob(job) },
                                    enabled = canApply,
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = ElectricTeal,
                                        contentColor = CharcoalBackground,
                                        disabledContainerColor = CharcoalSurfaceHigh,
                                        disabledContentColor = TextMuted
                                    ),
                                    modifier = Modifier.testTag("btn_apply_job_${job.id}")
                                ) {
                                    Text(
                                        text = if (!meetsAge) "Belum Cukup Umur" else if (!meetsIntellect) "Butuh Belajar Lagi" else "Lamar Posisi Ini",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
