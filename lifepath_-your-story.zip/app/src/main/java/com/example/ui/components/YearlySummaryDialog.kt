package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import com.example.util.FormatUtils
import com.example.viewmodel.YearlySummary

@Composable
fun YearlySummaryDialog(
    summary: YearlySummary,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.verticalGradient(listOf(AmberAccent, TealDark))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Celebration,
                        contentDescription = null,
                        tint = AmberAccent,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "SELAMAT ULANG TAHUN!",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 0.5.sp,
                            color = AmberAccent
                        )
                        Text(
                            text = "Kini kamu berusia ${summary.age} tahun (${summary.year})",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }

                HorizontalDivider(color = CharcoalOutline)

                // Financial Summary
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CharcoalCardVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Arus Kas Tahunan Bersih",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary
                            )
                            val isPositive = summary.netCashFlow >= 0
                            Text(
                                text = "${if (isPositive && summary.netCashFlow > 0) "+" else ""}${FormatUtils.formatRupiah(summary.netCashFlow)}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isPositive) ElectricTeal else RubyRed
                            )
                        }

                        if (summary.totalInflow > 0 || summary.totalOutflow > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "• Pemasukan: +${FormatUtils.formatRupiah(summary.totalInflow)}",
                                    fontSize = 10.sp,
                                    color = ElectricTeal
                                )
                                Text(
                                    text = "• Pengeluaran: -${FormatUtils.formatRupiah(summary.totalOutflow)}",
                                    fontSize = 10.sp,
                                    color = RubyRed
                                )
                            }
                        } else {
                            Text(
                                text = "Tidak ada pemasukan/pengeluaran mandiri (kebutuhan dasar ditanggung keluarga).",
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }
                    }
                }

                // Events that happened
                Text(
                    text = "Peristiwa di Tahun Ini:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    summary.events.forEach { ev ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CharcoalSurfaceHigh,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "• $ev",
                                fontSize = 11.sp,
                                color = TextPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricTeal,
                        contentColor = CharcoalBackground
                    )
                ) {
                    Text(
                        text = "LANJUTKAN KEHIDUPAN",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
