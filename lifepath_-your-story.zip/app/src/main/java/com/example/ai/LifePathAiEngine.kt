package com.example.ai

import com.example.BuildConfig
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class LifePathAiEngine {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun processAction(
        actionText: String,
        profile: CharacterProfile,
        stats: LifeStats,
        finance: FinancialState,
        relationships: List<Relationship>,
        recentEvents: List<TimelineEvent>
    ): ActionAiResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Local simulation mode with full realistic rules
            return@withContext simulateLocally(actionText, profile, stats, finance, relationships)
        }

        try {
            val responseJson = callGeminiApi(apiKey, actionText, profile, stats, finance, relationships, recentEvents)
            parseGeminiResponse(responseJson, profile, finance)
        } catch (e: Exception) {
            // Graceful fallback to local simulation if network or rate limit happens
            val fallback = simulateLocally(actionText, profile, stats, finance, relationships)
            fallback.copy(
                narrative = "${fallback.narrative}\n\n(Catatan: Beralih ke mesin simulasi lokal karena koneksi API bermasalah: ${e.localizedMessage ?: "timeout"})",
                isLocalSimulation = true
            )
        }
    }

    private fun getApiKey(): String {
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Exception) {
            ""
        }
    }

    private fun callGeminiApi(
        apiKey: String,
        actionText: String,
        profile: CharacterProfile,
        stats: LifeStats,
        finance: FinancialState,
        relationships: List<Relationship>,
        recentEvents: List<TimelineEvent>
    ): String {
        val systemInstruction = """
Kamu adalah AI Wasit dan Simulator Kehidupan untuk game realitas 'LIFEPATH: YOUR STORY'.
Setting: Indonesia kontemporer.
Peran kamu: Menerima aksi bebas pemain dalam bahasa Indonesia, lalu mengevaluasi secara ketat dan realistis berdasarkan status karakter saat ini.

ATURAN DUNIA GAME & EKONOMI REALISTIS:
1. Usia: Balita (0-5 thn), Anak SD (6-12), Remaja (13-17), Dewasa Muda (18-29), Dewasa (30-59), Lansia (60+). Tindakan harus masuk akal untuk usianya. Anak SD tidak bisa menerima gaji formal.
2. Keuangan & Arus Kas Realistis:
   - JANGAN menciptakan uang gratis tanpa sumber yang sah. Uang hanya berubah jika ada transaksi yang jelas.
   - Usaha Kecil / Penjualan: Jika pemain membawa es krim atau barang dari rumah tanpa biaya yang dibebankan kepada karakter, catat biaya modal Rp 0, dan laba adalah total penjualan.
   - Hitung laba bersih = total penjualan dikurangi modal/bahan nyata. Jika es krim berasal dari rumah secara cuma-cuma, jangan mengarang biaya pembelian.
   - Kategori transaksi (transaction_type): JOB_INCOME, BUSINESS_INCOME, ALLOWANCE_GIFT, PERSONAL_EXPENSE, BUSINESS_CAPITAL, OPERATING_COST, OTHER.
3. Pengeluaran: Cek saldo kas pemain. Jika aksi butuh modal/biaya melebihi saldo kas, aksi GAGAL (action_valid=false) dengan obstacle_reason jelas.
4. Kesehatan & Energi: Jika energi sangat rendah (<20) atau sakit, aksi fisik berat akan menurunkan kesehatan atau gagal.
5. Hubungan: Jika berinteraksi dengan NPC tertentu (ayah, ibu, sahabat, dll), pengaruhi tingkat kedekatan (closeness_delta: -30 s.d +30).
6. Konsekuensi realistis: Tindakan kriminal/ceroboh berisiko penjara, reputasi hancur, atau cedera. Tindakan tekun menambah kecerdasan/reputasi namun memakan energi.

FORMAT OUTPUT WAJIB:
Kembalikan HANYA format JSON valid tanpa tag markdown, tanpa tanda kutip tiga ```.
{
  "narrative": "Penjelasan naratif tentang apa yang terjadi setelah aksi dilakukan (2-4 kalimat).",
  "action_valid": true,
  "stat_changes": {
    "health": 0,
    "happiness": 5,
    "intellect": 10,
    "reputation": 2,
    "energy": -15
  },
  "financial_changes": {
    "cash_delta": 50000,
    "income_delta": 0,
    "expense_delta": 0,
    "transaction_type": "BUSINESS_INCOME",
    "transaction_description": "Penjualan es krim dari rumah (modal Rp 0)",
    "asset_name": null,
    "asset_value": 0,
    "debt_name": null,
    "debt_amount": 0
  },
  "new_events": [
    "Catatan timeline 1 kalimat (contoh: Kamu berhasil menyelesaikan kursus pemrograman Python)."
  ],
  "relationship_changes": [
    {
      "name": "Nama Anggota Keluarga/Teman",
      "closeness_delta": 10,
      "note": "Alasan hubungan berubah"
    }
  ],
  "obstacle_reason": null
}
""".trimIndent()

        val relSummary = relationships.joinToString("; ") { "${it.name} (${it.relationType.label}, kedekatan ${it.closeness}%)" }
        val recentEventsSummary = recentEvents.take(4).joinToString(" | ") { "Usia ${it.age}: ${it.text}" }

        val contextPrompt = """
STATUS KARAKTER SAAT INI:
- Nama: ${profile.name} (Gender: ${profile.gender.label}, Usia: ${profile.age} tahun, Kota: ${profile.birthCity})
- Profesi/Status: ${profile.occupation} (Pendidikan: ${profile.educationLevel})
- Latar Belakang: ${profile.backgroundTrait}
- Sifat Karakter (Personality): ${profile.personalityTraits.joinToString(", ")}
- Statistik: Kesehatan=${stats.health}/100, Kebahagiaan=${stats.happiness}/100, Kecerdasan=${stats.intellect}/100, Reputasi=${stats.reputation}/100, Energi=${stats.energy}/100
- Keuangan: Saldo Kas = Rp ${finance.cash}, Pemasukan/bln = Rp ${finance.monthlyIncome}, Pengeluaran/bln = Rp ${finance.monthlyExpense}
- Aset yang dimiliki: ${finance.assets.joinToString { it.name }}
- Hubungan terdekat: $relSummary
- Kejadian terakhir: $recentEventsSummary

TINDAKAN YANG INGIN DILAKUKAN PEMAIN:
"$actionText"

Analisis tindakan ini, pertimbangkan sifat kepribadian karakter (${profile.personalityTraits.joinToString(", ")}) dan reputasinya (${stats.reputation}/100) dalam membentuk respons NPC dan konsekuensi, lalu kembalikan format JSON persis sesuai panduan.
""".trimIndent()

        val rootRequest = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply { put("text", systemInstruction) })
                })
            })
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", contextPrompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            })
        }

        val requestBody = rootRequest.toString().toRequestBody("application/json".toMediaType())
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw RuntimeException("Empty response body from Gemini API")
        if (!response.isSuccessful) {
            throw RuntimeException("Gemini API error ${response.code}: $responseBody")
        }

        val jsonObj = JSONObject(responseBody)
        val candidates = jsonObj.optJSONArray("candidates")
        val firstCandidate = candidates?.optJSONObject(0)
        val content = firstCandidate?.optJSONObject("content")
        val parts = content?.optJSONArray("parts")
        val text = parts?.optJSONObject(0)?.optString("text") ?: throw RuntimeException("No text in candidate response")

        return text
    }

    private fun parseGeminiResponse(rawText: String, profile: CharacterProfile, finance: FinancialState): ActionAiResult {
        var cleanJson = rawText.trim()
        if (cleanJson.startsWith("```json")) {
            cleanJson = cleanJson.removePrefix("```json")
        }
        if (cleanJson.startsWith("```")) {
            cleanJson = cleanJson.removePrefix("```")
        }
        if (cleanJson.endsWith("```")) {
            cleanJson = cleanJson.removeSuffix("```")
        }
        cleanJson = cleanJson.trim()

        val obj = JSONObject(cleanJson)
        val narrative = obj.optString("narrative", "Tindakan berhasil dijalankan.")
        val actionValid = obj.optBoolean("action_valid", true)

        val statChangesMap = mutableMapOf<String, Int>()
        val statObj = obj.optJSONObject("stat_changes")
        if (statObj != null) {
            statObj.keys().forEach { key ->
                // Clamp stat deltas to avoid insane exploits
                val delta = statObj.optInt(key, 0).coerceIn(-40, 40)
                statChangesMap[key] = delta
            }
        }

        val finObj = obj.optJSONObject("financial_changes")
        var cashDelta = finObj?.optLong("cash_delta", 0L) ?: 0L
        val incDelta = finObj?.optLong("income_delta", 0L) ?: 0L
        val expDelta = finObj?.optLong("expense_delta", 0L) ?: 0L
        val assetName = finObj?.optString("asset_name")?.takeIf { it.isNotBlank() && it != "null" }
        val assetVal = finObj?.optLong("asset_value", 0L) ?: 0L
        val debtName = finObj?.optString("debt_name")?.takeIf { it.isNotBlank() && it != "null" }
        val debtAmt = finObj?.optLong("debt_amount", 0L) ?: 0L

        // Safety verification: cannot spend more money than available
        if (cashDelta < 0 && (finance.cash + cashDelta) < 0) {
            cashDelta = -finance.cash // cannot go below zero cash
        }

        val newAsset = if (assetName != null && assetVal > 0) {
            AssetItem(id = "ast_${System.currentTimeMillis()}", name = assetName, value = assetVal, category = "Aset Baru")
        } else null

        val newDebt = if (debtName != null && debtAmt > 0) {
            DebtItem(id = "debt_${System.currentTimeMillis()}", name = debtName, totalAmount = debtAmt, monthlyPayment = debtAmt / 12)
        } else null

        val newEvents = mutableListOf<String>()
        val eventsArr = obj.optJSONArray("new_events")
        if (eventsArr != null) {
            for (i in 0 until eventsArr.length()) {
                val ev = eventsArr.optString(i)
                if (ev.isNotBlank()) newEvents.add(ev)
            }
        }
        if (newEvents.isEmpty() && narrative.isNotBlank()) {
            newEvents.add(narrative.take(120))
        }

        val relChanges = mutableListOf<RelationshipDelta>()
        val relArr = obj.optJSONArray("relationship_changes")
        if (relArr != null) {
            for (i in 0 until relArr.length()) {
                val rObj = relArr.optJSONObject(i) ?: continue
                val name = rObj.optString("name", "Keluarga")
                val delta = rObj.optInt("closeness_delta", 0).coerceIn(-35, 35)
                val note = rObj.optString("note", "")
                relChanges.add(RelationshipDelta(name = name, closenessDelta = delta, note = note))
            }
        }

        val obstacle = obj.optString("obstacle_reason").takeIf { it.isNotBlank() && it != "null" }

        val txTypeStr = finObj?.optString("transaction_type", "") ?: ""
        val txType = try {
            if (txTypeStr.isNotBlank()) TransactionType.valueOf(txTypeStr) else null
        } catch (_: Exception) { null } ?: when {
            cashDelta > 0 && (narrative.lowercase().contains("es krim") || narrative.lowercase().contains("jual") || narrative.lowercase().contains("usaha")) -> TransactionType.BUSINESS_INCOME
            cashDelta > 0 && (narrative.lowercase().contains("gaji") || narrative.lowercase().contains("upah")) -> TransactionType.JOB_INCOME
            cashDelta > 0 && (narrative.lowercase().contains("uang saku") || narrative.lowercase().contains("hadiah")) -> TransactionType.ALLOWANCE_GIFT
            cashDelta < 0 && (narrative.lowercase().contains("modal") || narrative.lowercase().contains("investasi")) -> TransactionType.BUSINESS_CAPITAL
            cashDelta < 0 && (narrative.lowercase().contains("operasional") || narrative.lowercase().contains("sewa")) -> TransactionType.OPERATING_COST
            cashDelta < 0 -> TransactionType.PERSONAL_EXPENSE
            else -> TransactionType.OTHER
        }
        val txDesc = finObj?.optString("transaction_description", "").takeIf { !it.isNullOrBlank() } ?: narrative.take(70)

        return ActionAiResult(
            narrative = narrative,
            actionValid = actionValid,
            statChanges = statChangesMap,
            financialChanges = FinancialDelta(
                cashDelta = cashDelta,
                monthlyIncomeDelta = incDelta,
                monthlyExpenseDelta = expDelta,
                newAsset = newAsset,
                newDebt = newDebt,
                transactionType = txType,
                transactionDescription = txDesc
            ),
            newEvents = newEvents,
            relationshipChanges = relChanges,
            obstacleReason = obstacle,
            isLocalSimulation = false
        )
    }

    /**
     * Local semantic simulation engine that interprets everyday Indonesian actions.
     * Complies with the prompt requirement:
     * "Jika API belum dikonfigurasi, buat mode demo lokal dengan respons simulasi agar fitur dasar tetap dapat diuji.
     * Beri label bahwa mode demo belum menggunakan AI sungguhan."
     */
    fun simulateLocally(
        actionText: String,
        profile: CharacterProfile,
        stats: LifeStats,
        finance: FinancialState,
        relationships: List<Relationship>
    ): ActionAiResult {
        val lower = actionText.lowercase()

        val hasCreative = profile.personalityTraits.any { it.contains("Kreatif", ignoreCase = true) }
        val hasAmbitious = profile.personalityTraits.any { it.contains("Ambisius", ignoreCase = true) }
        val hasEmpathetic = profile.personalityTraits.any { it.contains("Empatik", ignoreCase = true) }
        val hasFrugal = profile.personalityTraits.any { it.contains("Hemat", ignoreCase = true) }
        val hasCharismatic = profile.personalityTraits.any { it.contains("Karismatik", ignoreCase = true) }
        val hasDisciplined = profile.personalityTraits.any { it.contains("Disiplin", ignoreCase = true) }

        // 1. Age constraint check for young kids
        if (profile.age < 6) {
            return if (lower.contains("main") || lower.contains("tidur") || lower.contains("makan") || lower.contains("nangis") || lower.contains("ibu") || lower.contains("ayah")) {
                ActionAiResult(
                    narrative = "Sebagai balita berusia ${profile.age} tahun, kamu bermain dengan gembira di lantai rumah. Ayah dan ibumu tersenyum melihat tingkah lucumu.",
                    actionValid = true,
                    statChanges = mapOf("happiness" to 8, "energy" to -5, "health" to 3),
                    financialChanges = FinancialDelta(),
                    newEvents = listOf("Usia ${profile.age}: Kamu menghabiskan hari bermain ceria bersama orang tua."),
                    relationshipChanges = listOf(
                        RelationshipDelta(name = "Ibu", closenessDelta = 6, note = "Momen bermain menyenangkan"),
                        RelationshipDelta(name = "Ayah", closenessDelta = 5, note = "Momen bermain menyenangkan")
                    ),
                    isLocalSimulation = true
                )
            } else {
                ActionAiResult(
                    narrative = "Kamu masih berusia ${profile.age} tahun dan belum memahami konsep '$actionText'. Orang tuamu segera menggendongmu dan memberimu mainan.",
                    actionValid = false,
                    statChanges = mapOf("happiness" to 2, "energy" to -2),
                    obstacleReason = "Usia terlalu dini untuk melakukan tindakan tersebut.",
                    newEvents = listOf("Usia ${profile.age}: Kamu mencoba hal di luar usiamu tapi dijaga orang tua."),
                    isLocalSimulation = true
                )
            }
        }

        // 1.5. Small commerce & selling items (e.g., "es krim", "jual es krim dari rumah", "jualan kecil", "dagang")
        if (lower.contains("es krim") || (lower.contains("jual") && (lower.contains("rumah") || lower.contains("tetangga") || lower.contains("teman") || lower.contains("kecil") || profile.age < 18))) {
            val isFromHome = lower.contains("rumah") || lower.contains("kulkas") || lower.contains("dapur") || !lower.contains("modal")
            val capitalCost = if (isFromHome) 0L else 15_000L
            val saleRevenue = when {
                profile.age < 13 -> 35_000L // Anak SD jualan es krim
                profile.age < 18 -> 60_000L // Remaja
                else -> 100_000L
            }
            val netProfit = (saleRevenue - capitalCost).coerceAtLeast(0L)

            val explanation = if (isFromHome) {
                "Kamu membawa es krim dari rumah tanpa biaya yang dibebankan padamu (modal Rp 0), lalu menjualnya kepada teman dan tetangga sekitar. Seluruh hasil penjualan sebesar Rp $saleRevenue menjadi laba bersih usaha kecilmu!"
            } else {
                "Kamu menyiapkan modal bahan sebesar Rp $capitalCost dan berhasil menjualnya seharga Rp $saleRevenue. Laba bersih yang kamu kantongi sebesar Rp $netProfit."
            }

            return ActionAiResult(
                narrative = explanation,
                actionValid = true,
                statChanges = mapOf("happiness" to 8, "intellect" to 4, "reputation" to 3, "energy" to -10),
                financialChanges = FinancialDelta(
                    cashDelta = netProfit,
                    transactionType = TransactionType.BUSINESS_INCOME,
                    transactionDescription = if (isFromHome) "Penjualan es krim dari rumah (modal Rp 0, hasil Rp $saleRevenue)" else "Laba penjualan es krim (hasil Rp $saleRevenue - modal Rp $capitalCost)"
                ),
                newEvents = listOf(if (isFromHome) "Berhasil menjual es krim dari rumah dengan laba Rp $netProfit." else "Menjalankan usaha kecil es krim dengan laba Rp $netProfit."),
                relationshipChanges = listOf(
                    RelationshipDelta(name = "Keluarga", closenessDelta = 4, note = "Melihat bakat wirausahamu sejak dini")
                ),
                isLocalSimulation = true
            )
        }

        // 2. Business & Entrepreneurship (e.g., "buka kedai kopi modal 10 juta", "buka usaha")
        if (lower.contains("usaha") || lower.contains("bisnis") || lower.contains("kedai") || lower.contains("toko") || lower.contains("jualan") || lower.contains("startup") || lower.contains("cafe") || lower.contains("kopi")) {
            val estimatedCapital = when {
                lower.contains("10 jt") || lower.contains("10 juta") || lower.contains("10.000.000") -> 10_000_000L
                lower.contains("50 jt") || lower.contains("50 juta") -> 50_000_000L
                lower.contains("5 jt") || lower.contains("5 juta") -> 5_000_000L
                lower.contains("20 jt") || lower.contains("20 juta") -> 20_000_000L
                else -> 10_000_000L
            }

            if (finance.cash < estimatedCapital) {
                return ActionAiResult(
                    narrative = "Kamu berencana memulai usaha ini, namun saldo kasmu (Rp ${finance.cash}) tidak mencukupi estimasi modal yang dibutuhkan (Rp $estimatedCapital). Kamu perlu mengumpulkan modal lebih banyak atau mencari pinjaman.",
                    actionValid = false,
                    statChanges = mapOf("happiness" to -5, "intellect" to 3),
                    financialChanges = FinancialDelta(),
                    obstacleReason = "Modal kas tidak mencukupi untuk mendirikan usaha tersebut.",
                    newEvents = listOf("Kamu menyusun rencana bisnis, namun menyadari modal belum mencukupi."),
                    isLocalSimulation = true
                )
            }

            val businessName = if (lower.contains("kopi") || lower.contains("kedai")) "Kedai Kopi Mandiri" else "Usaha Bisnis Mandiri"
            val monthlyProfit = (estimatedCapital * 0.15).toLong().coerceAtLeast(1_500_000L)
            return ActionAiResult(
                narrative = "Dengan tekad kuat, kamu mengalokasikan modal Rp $estimatedCapital untuk mendirikan $businessName. Pembukaan berjalan sukses, aroma kopi dan sambutan hangat para pelanggan pertama membawa optimisme baru!",
                actionValid = true,
                statChanges = mapOf("happiness" to 15, "intellect" to 8, "reputation" to 12, "energy" to -25),
                financialChanges = FinancialDelta(
                    cashDelta = -estimatedCapital,
                    monthlyIncomeDelta = monthlyProfit,
                    newAsset = AssetItem(
                        id = "ast_biz_${System.currentTimeMillis()}",
                        name = businessName,
                        value = estimatedCapital * 2,
                        category = "Bisnis",
                        monthlyMaintenance = 500_000L
                    )
                ),
                newEvents = listOf("Resmi merintis $businessName dengan modal Rp $estimatedCapital."),
                relationshipChanges = listOf(
                    RelationshipDelta(name = "Keluarga", closenessDelta = 8, note = "Mendukung langkah kewirausahaanmu")
                ),
                isLocalSimulation = true
            )
        }

        // 3. Learning & Programming ("belajar pemrograman", "coding", "kursus", "baca buku")
        if (lower.contains("belajar") || lower.contains("program") || lower.contains("coding") || lower.contains("kursus") || lower.contains("buku") || lower.contains("otodidak") || lower.contains("kuliah")) {
            val cost = if (lower.contains("kursus") || lower.contains("bootcamp")) 1_500_000L else 150_000L
            val actualCost = if (finance.cash >= cost) cost else 0L

            return ActionAiResult(
                narrative = "Kamu mendedikasikan waktu berjam-jam untuk mempelajari materi pemrograman dan logika algoritma. Perlahan-lahan konsep yang awalnya rumit mulai terasa masuk akal di kepalamu.",
                actionValid = true,
                statChanges = mapOf("intellect" to 12, "happiness" to 4, "energy" to -15),
                financialChanges = FinancialDelta(cashDelta = -actualCost),
                newEvents = listOf("Kamu tekun belajar keterampilan baru dan memperluas wawasan intelektual."),
                isLocalSimulation = true
            )
        }

        // 4. Job application / Career ("melamar kerja", "cari kerja", "interview", "magang")
        if (lower.contains("lamar") || lower.contains("kerja") || lower.contains("magang") || lower.contains("kantor") || lower.contains("cv") || lower.contains("interview")) {
            if (profile.age < 17) {
                return ActionAiResult(
                    narrative = "Usiamu saat ini (${profile.age} tahun) belum memenuhi syarat legal ketenagakerjaan untuk pekerjaan profesional penuh waktu. Fokuslah menyelesaikan sekolah terlebih dahulu.",
                    actionValid = false,
                    statChanges = mapOf("happiness" to -3, "intellect" to 2),
                    obstacleReason = "Belum cukup umur untuk kontrak kerja profesional.",
                    isLocalSimulation = true
                )
            }

            val isAccepted = stats.intellect >= 60 && stats.energy >= 30
            if (isAccepted) {
                val salary = if (stats.intellect >= 80) 8_500_000L else 5_000_000L
                val jobTitle = if (lower.contains("teknologi") || lower.contains("tech")) "Junior Developer di PT Teknologi Inovasi" else "Staf Operasional Perusahaan"
                return ActionAiResult(
                    narrative = "Surat lamaran dan portofoliomu memikat HRD! Setelah wawancara mendalam, kamu resmi dinyatakan diterima sebagai $jobTitle dengan gaji Rp $salary/bulan.",
                    actionValid = true,
                    statChanges = mapOf("happiness" to 18, "reputation" to 10, "energy" to -10),
                    financialChanges = FinancialDelta(monthlyIncomeDelta = salary),
                    newEvents = listOf("Diterima bekerja sebagai $jobTitle (Gaji Rp $salary/bln)."),
                    relationshipChanges = listOf(
                        RelationshipDelta(name = "Ayah", closenessDelta = 10, note = "Bangga melihatmu mandiri")
                    ),
                    isLocalSimulation = true
                )
            } else {
                return ActionAiResult(
                    narrative = "Kamu mengirimkan CV dan mengikuti tes seleksi. Sayangnya, persaingan sangat ketat dan pihak perusahaan memutuskan untuk tidak melanjutkan ke tahap berikutnya kali ini.",
                    actionValid = true,
                    statChanges = mapOf("happiness" to -8, "energy" to -10, "intellect" to 3),
                    newEvents = listOf("Mengikuti proses wawancara kerja, namun belum membuahkan hasil."),
                    isLocalSimulation = true
                )
            }
        }

        // 5. Relationship ("memperbaiki hubungan dengan ayah", "ibu", "kencan", "ngobrol")
        if (lower.contains("ayah") || lower.contains("ibu") || lower.contains("orang tua") || lower.contains("hubungan") || lower.contains("maaf") || lower.contains("pacar") || lower.contains("kencan") || lower.contains("teman") || lower.contains("sahabat")) {
            val targetName = when {
                lower.contains("ayah") -> "Ayah"
                lower.contains("ibu") -> "Ibu"
                lower.contains("pacar") || lower.contains("kencan") -> "Pasangan"
                lower.contains("teman") || lower.contains("sahabat") -> "Sahabat"
                else -> "Keluarga"
            }

            return ActionAiResult(
                narrative = "Kamu meluangkan waktu dari hati ke hati untuk berbicara dengan $targetName. Meski ada momen canggung di awal, obrolan tulus ini mencairkan suasana dan mempererat ikatan batin kalian.",
                actionValid = true,
                statChanges = mapOf("happiness" to 14, "health" to 2, "energy" to -8),
                financialChanges = FinancialDelta(cashDelta = -150_000L), // biaya ngopi/makan bersama
                newEvents = listOf("Menghabiskan waktu berkualitas dan memperbaiki hubungan dengan $targetName."),
                relationshipChanges = listOf(
                    RelationshipDelta(name = targetName, closenessDelta = 15, note = "Percakapan tulus dan saling memaafkan")
                ),
                isLocalSimulation = true
            )
        }

        // 6. Moving city ("pindah kota", "merantau", "hidup baru")
        if (lower.contains("pindah") || lower.contains("merantau") || lower.contains("hidup baru") || lower.contains("sewa kost")) {
            val movingCost = 3_500_000L
            if (finance.cash < movingCost) {
                return ActionAiResult(
                    narrative = "Kamu sangat ingin merantau dan memulai hidup baru di kota lain, namun biaya sewa kost dan tiket perjalanan membutuhkan setidaknya Rp $movingCost, sedangkan tabunganmu belum mencukupi.",
                    actionValid = false,
                    statChanges = mapOf("happiness" to -5),
                    obstacleReason = "Saldo tabungan belum cukup untuk biaya pindah dan deposit sewa tempat tinggal.",
                    isLocalSimulation = true
                )
            }

            return ActionAiResult(
                narrative = "Kamu mengemas semua pakaian ke dalam koper, berpamitan dengan haru, dan melangkahkan kaki menuju kota baru untuk membuka babak kehidupan yang segar.",
                actionValid = true,
                statChanges = mapOf("happiness" to 10, "reputation" to 5, "energy" to -20),
                financialChanges = FinancialDelta(cashDelta = -movingCost),
                newEvents = listOf("Memutuskan pindah kota dan merantau untuk mencari pengalaman baru."),
                relationshipChanges = listOf(
                    RelationshipDelta(name = "Keluarga", closenessDelta = -5, note = "Tinggal berjauhan beda kota")
                ),
                isLocalSimulation = true
            )
        }

        // 7. Health & Wellness ("olahraga", "gym", "istirahat", "dokter", "tidur")
        if (lower.contains("olahraga") || lower.contains("gym") || lower.contains("lari") || lower.contains("sehat") || lower.contains("istirahat") || lower.contains("tidur") || lower.contains("checkup")) {
            return ActionAiResult(
                narrative = "Kamu meluangkan waktu merawat tubuhmu dengan olahraga teratur dan istirahat yang cukup. Otot terasa lebih bugar dan pikiranmu menjadi jauh lebih jernih.",
                actionValid = true,
                statChanges = mapOf("health" to 12, "energy" to 15, "happiness" to 8),
                financialChanges = FinancialDelta(cashDelta = -100_000L),
                newEvents = listOf("Menjaga pola hidup sehat dan rutin melatih kebugaran jasmani."),
                isLocalSimulation = true
            )
        }

        // 8. General fallback simulation
        return ActionAiResult(
            narrative = "Kamu mengambil inisiatif melakukan '$actionText'. Usaha ini memberikan pengalaman hidup berharga yang membentuk kepribadian dan arah masa depanmu.",
            actionValid = true,
            statChanges = mapOf("happiness" to 5, "intellect" to 3, "energy" to -10),
            financialChanges = FinancialDelta(),
            newEvents = listOf("Melakukan tindakan: $actionText."),
            isLocalSimulation = true
        )
    }
}
