package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.LifePathAiEngine
import com.example.data.CareerData
import com.example.data.GameStateRepository
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class MainTab(val label: String) {
    DASHBOARD("Kehidupan"),
    STUDIO("Studio & Toko"),
    RELATIONSHIPS("Hubungan"),
    CAREER("Karier"),
    ACHIEVEMENTS("Prestasi")
}

data class YearlySummary(
    val age: Int,
    val year: Int,
    val netCashFlow: Long,
    val totalInflow: Long = 0L,
    val totalOutflow: Long = 0L,
    val events: List<String>,
    val healthChange: Int,
    val happinessChange: Int
)

data class LifePathUiState(
    val profile: CharacterProfile = CharacterProfile(),
    val stats: LifeStats = LifeStats(),
    val finance: FinancialState = FinancialState(),
    val relationships: List<Relationship> = emptyList(),
    val timeline: List<TimelineEvent> = emptyList(),
    val achievements: List<GameAchievement> = emptyList(),
    val currentTab: MainTab = MainTab.DASHBOARD,
    val isProcessingAction: Boolean = false,
    val lastActionResult: ActionAiResult? = null,
    val actionInputText: String = "",
    val yearlySummaryDialog: YearlySummary? = null,
    val isGameOver: Boolean = false,
    val showNewGameDialog: Boolean = false,
    val showSettingsDialog: Boolean = false,
    val errorMessage: String? = null,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true
)

class LifePathViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GameStateRepository(application)
    private val aiEngine = LifePathAiEngine()

    private val _uiState = MutableStateFlow(LifePathUiState())
    val uiState: StateFlow<LifePathUiState> = _uiState.asStateFlow()

    init {
        loadOrInitializeGame()
    }

    private fun loadOrInitializeGame() {
        if (repository.hasSavedGame()) {
            val prof = repository.loadProfile()
            val stats = repository.loadStats()
            val fin = repository.loadFinance()
            val rels = repository.loadRelationships()
            val time = repository.loadTimeline()
            val achs = repository.loadAchievements()
            _uiState.update {
                it.copy(
                    profile = prof,
                    stats = stats,
                    finance = fin,
                    relationships = rels,
                    timeline = time,
                    achievements = achs,
                    isGameOver = !prof.isAlive
                )
            }
        } else {
            startNewGame(
                name = "Aditya Pratama",
                gender = Gender.MALE,
                startAge = 18,
                birthCity = "Jakarta",
                background = "Keluarga Menengah Pekerja Keras"
            )
        }
    }

    fun onTabSelected(tab: MainTab) {
        _uiState.update { it.copy(currentTab = tab) }
        triggerHaptic()
    }

    fun onActionInputChanged(text: String) {
        _uiState.update { it.copy(actionInputText = text) }
    }

    fun clearLastActionResult() {
        _uiState.update { it.copy(lastActionResult = null) }
    }

    fun dismissYearlySummary() {
        _uiState.update { it.copy(yearlySummaryDialog = null) }
    }

    fun setShowNewGameDialog(show: Boolean) {
        _uiState.update { it.copy(showNewGameDialog = show) }
    }

    fun setShowSettingsDialog(show: Boolean) {
        _uiState.update { it.copy(showSettingsDialog = show) }
    }

    fun toggleVibration() {
        _uiState.update { it.copy(vibrationEnabled = !it.vibrationEnabled) }
    }

    fun toggleSound() {
        _uiState.update { it.copy(soundEnabled = !it.soundEnabled) }
    }

    fun submitFreeAction(customAction: String? = null) {
        val actionText = (customAction ?: _uiState.value.actionInputText).trim()
        if (actionText.isEmpty() || _uiState.value.isProcessingAction || _uiState.value.isGameOver) return

        _uiState.update { it.copy(isProcessingAction = true, errorMessage = null) }
        triggerHaptic()

        viewModelScope.launch {
            try {
                val currentState = _uiState.value
                val result = aiEngine.processAction(
                    actionText = actionText,
                    profile = currentState.profile,
                    stats = currentState.stats,
                    finance = currentState.finance,
                    relationships = currentState.relationships,
                    recentEvents = currentState.timeline
                )

                applyActionResult(result, actionText)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessingAction = false,
                        errorMessage = "Gagal memproses tindakan: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    private fun applyActionResult(result: ActionAiResult, originalAction: String) {
        val current = _uiState.value

        // 1. Update stats
        val updatedStats = current.stats.copy(
            health = (current.stats.health + (result.statChanges["health"] ?: 0)).coerceIn(0, 100),
            happiness = (current.stats.happiness + (result.statChanges["happiness"] ?: 0)).coerceIn(0, 100),
            intellect = (current.stats.intellect + (result.statChanges["intellect"] ?: 0)).coerceIn(0, 100),
            reputation = (current.stats.reputation + (result.statChanges["reputation"] ?: 0)).coerceIn(0, 100),
            energy = (current.stats.energy + (result.statChanges["energy"] ?: 0)).coerceIn(0, 100)
        )

        // 2. Update finance using EconomyEngine validation
        val validatedDelta = com.example.economy.EconomyEngine.validateAiFinancialProposal(
            proposal = result.financialChanges,
            currentFinance = current.finance,
            profile = current.profile,
            actionText = originalAction
        )

        var updatedFinance = current.finance
        if (validatedDelta.cashDelta != 0L) {
            val (procFin, _) = com.example.economy.EconomyEngine.processTransaction(
                currentFinance = updatedFinance,
                age = current.profile.age,
                year = current.profile.currentYear,
                type = validatedDelta.transactionType,
                amount = validatedDelta.cashDelta,
                description = if (validatedDelta.transactionDescription.isNotBlank()) validatedDelta.transactionDescription else originalAction,
                source = "Tindakan Bebas"
            )
            updatedFinance = procFin
        }

        val newIncome = (updatedFinance.monthlyIncome + validatedDelta.monthlyIncomeDelta).coerceAtLeast(0L)
        val newExpense = (updatedFinance.monthlyExpense + validatedDelta.monthlyExpenseDelta).coerceAtLeast(0L)

        val updatedAssets = updatedFinance.assets.toMutableList()
        if (validatedDelta.newAsset != null) {
            updatedAssets.add(validatedDelta.newAsset)
        }

        val updatedDebts = updatedFinance.debts.toMutableList()
        if (validatedDelta.newDebt != null) {
            updatedDebts.add(validatedDelta.newDebt)
        }

        updatedFinance = updatedFinance.copy(
            monthlyIncome = newIncome,
            monthlyExpense = newExpense,
            assets = updatedAssets,
            debts = updatedDebts
        )

        // 3. Update relationships
        val updatedRels = current.relationships.map { rel ->
            val match = result.relationshipChanges.find {
                it.name.contains(rel.name, ignoreCase = true) ||
                rel.name.contains(it.name, ignoreCase = true) ||
                rel.relationType.label.equals(it.name, ignoreCase = true)
            }
            if (match != null) {
                rel.copy(
                    closeness = (rel.closeness + match.closenessDelta).coerceIn(0, 100),
                    statusDescription = if (match.note.isNotBlank()) match.note else rel.statusDescription
                )
            } else rel
        }

        // 4. Update timeline
        val newTimelineList = current.timeline.toMutableList()
        result.newEvents.forEach { evText ->
            newTimelineList.add(
                0,
                TimelineEvent(
                    id = "ev_${System.currentTimeMillis()}_${Random.nextInt(1000)}",
                    age = current.profile.age,
                    year = current.profile.currentYear,
                    text = evText,
                    category = if (result.actionValid) EventCategory.GENERAL else EventCategory.CAREER
                )
            )
        }

        // 5. Check death condition
        val isDead = updatedStats.health <= 0
        val updatedProfile = if (isDead) {
            current.profile.copy(
                isAlive = false,
                causeOfDeath = "Kelelahan fatal dan penurunan drastis kondisi fisik."
            )
        } else current.profile

        // 6. Check achievements
        val updatedAchievements = checkAchievements(
            current.achievements,
            updatedStats,
            updatedFinance,
            updatedProfile,
            updatedRels
        )

        _uiState.update {
            it.copy(
                profile = updatedProfile,
                stats = updatedStats,
                finance = updatedFinance,
                relationships = updatedRels,
                timeline = newTimelineList,
                achievements = updatedAchievements,
                isProcessingAction = false,
                lastActionResult = result,
                actionInputText = "",
                isGameOver = isDead
            )
        }

        saveCurrentState()
        triggerHaptic()
    }

    /**
     * Advances time by 1 year ("LANJUTKAN WAKTU").
     * Simulates 12 months of income/expenses, age increment, health aging, random life events.
     */
    fun advanceOneYear() {
        if (_uiState.value.isGameOver) return

        val current = _uiState.value
        val newAge = current.profile.age + 1
        val newYear = current.profile.currentYear + 1

        // 1. Calculate realistic annual finances using EconomyEngine
        val econResult = com.example.economy.EconomyEngine.evaluateYearlyFlow(
            profile = current.profile,
            finance = current.finance,
            age = newAge,
            year = newYear
        )
        val updatedFinance = econResult.updatedFinance
        val netCashFlow = econResult.netCashFlow

        // 2. Generate age-appropriate random life events
        val randomEvents = generateYearlyEvents(newAge, current.stats, current.relationships, updatedFinance)

        // 3. Stats progression
        var healthDelta = if (newAge > 60) -Random.nextInt(2, 6) else Random.nextInt(-2, 3)
        var happinessDelta = Random.nextInt(-4, 5)
        var energyDelta = if (newAge > 65) -Random.nextInt(1, 4) else 0

        // Apply stat changes from random events
        randomEvents.forEach { ev ->
            when (ev.type) {
                "HEALTH_GOOD" -> healthDelta += 5
                "HEALTH_BAD" -> healthDelta -= 12
                "HAPPINESS_GOOD" -> happinessDelta += 10
                "HAPPINESS_BAD" -> happinessDelta -= 8
                "CAREER_PROMO" -> {
                    happinessDelta += 8
                }
            }
        }

        val updatedStats = current.stats.copy(
            health = (current.stats.health + healthDelta).coerceIn(0, 100),
            happiness = (current.stats.happiness + happinessDelta).coerceIn(0, 100),
            energy = (current.stats.energy + energyDelta).coerceIn(0, 100)
        )

        // 4. Age relationships
        val updatedRels = current.relationships.map { rel ->
            val relClosenessDelta = Random.nextInt(-3, 4)
            rel.copy(
                age = rel.age + 1,
                closeness = (rel.closeness + relClosenessDelta).coerceIn(0, 100)
            )
        }

        // 5. Update life stage and occupation if natural milestones occur
        val (newStage, newOcc) = updateStageAndOccupation(newAge, current.profile.occupation)
        val isDead = updatedStats.health <= 0 || newAge >= 98
        val causeOfDeath = if (isDead) {
            if (newAge >= 98) "Meninggal dunia dengan tenang di usia senja karena faktor usia lanjut."
            else "Kondisi kesehatan menurun drastis dan komplikasi medis."
        } else null

        val updatedProfile = current.profile.copy(
            age = newAge,
            currentYear = newYear,
            lifeStageDescription = newStage,
            occupation = newOcc,
            isAlive = !isDead,
            causeOfDeath = causeOfDeath
        )

        // 6. Record timeline events
        val newTimeline = current.timeline.toMutableList()
        val eventTexts = mutableListOf<String>()
        randomEvents.forEach { ev ->
            eventTexts.add(ev.text)
            newTimeline.add(
                0,
                TimelineEvent(
                    id = "ev_${newAge}_${System.currentTimeMillis()}_${Random.nextInt(100)}",
                    age = newAge,
                    year = newYear,
                    text = ev.text,
                    category = ev.category
                )
            )
        }
        if (eventTexts.isEmpty()) {
            val genericYearText = "Tahun $newYear berlalu dengan tenang. Kamu menjalani rutinitas harian dengan baik."
            eventTexts.add(genericYearText)
            newTimeline.add(
                0,
                TimelineEvent(
                    id = "ev_generic_${newAge}",
                    age = newAge,
                    year = newYear,
                    text = genericYearText,
                    category = EventCategory.GENERAL
                )
            )
        }

        // 7. Check achievements
        val updatedAchievements = checkAchievements(
            current.achievements,
            updatedStats,
            updatedFinance,
            updatedProfile,
            updatedRels
        )

        val summary = YearlySummary(
            age = newAge,
            year = newYear,
            netCashFlow = netCashFlow,
            totalInflow = econResult.totalInflow,
            totalOutflow = econResult.totalOutflow,
            events = eventTexts,
            healthChange = healthDelta,
            happinessChange = happinessDelta
        )

        _uiState.update {
            it.copy(
                profile = updatedProfile,
                stats = updatedStats,
                finance = updatedFinance,
                relationships = updatedRels,
                timeline = newTimeline,
                achievements = updatedAchievements,
                yearlySummaryDialog = summary,
                isGameOver = isDead
            )
        }

        saveCurrentState()
        triggerHaptic()
    }

    private data class RandomEventData(
        val text: String,
        val category: EventCategory,
        val type: String
    )

    private fun generateYearlyEvents(
        age: Int,
        stats: LifeStats,
        relationships: List<Relationship>,
        finance: FinancialState
    ): List<RandomEventData> {
        val list = mutableListOf<RandomEventData>()

        when {
            age == 6 -> list.add(RandomEventData("Kamu resmi memulai hari pertama bersekolah di Sekolah Dasar. Seragam merah putih baru membuatmu bangga.", EventCategory.EDUCATION, "HAPPINESS_GOOD"))
            age == 12 -> list.add(RandomEventData("Lulus dari Sekolah Dasar dengan nilai yang membanggakan orang tua.", EventCategory.EDUCATION, "HAPPINESS_GOOD"))
            age == 15 -> list.add(RandomEventData("Memulai jenjang SMA. Kamu mulai menentukan minat masa depanmu.", EventCategory.EDUCATION, "GENERAL"))
            age == 18 -> list.add(RandomEventData("Selamat! Kamu merayakan kelulusan SMA. Kini kamu resmi memasuki fase kedewasaan mandiri.", EventCategory.MILESTONE, "HAPPINESS_GOOD"))
            age == 23 && finance.monthlyIncome == 0L -> list.add(RandomEventData("Kamu merasakan dorongan kuat untuk segera memiliki kemandirian finansial dan tidak bergantung lagi pada orang tua.", EventCategory.CAREER, "GENERAL"))
            age == 30 -> list.add(RandomEventData("Menginjak usia kepala tiga. Kamu merenungkan pencapaian masa muda dan target dekade berikutnya.", EventCategory.MILESTONE, "GENERAL"))
            age == 50 -> list.add(RandomEventData("Merayakan setengah abad perjalanan hidup bersama orang-orang tercinta.", EventCategory.MILESTONE, "HAPPINESS_GOOD"))
            age == 65 -> list.add(RandomEventData("Memasuki usia pensiun emas. Waktu luangmu kini lebih banyak didedikasikan untuk hobi dan keluarga.", EventCategory.MILESTONE, "GENERAL"))
        }

        // Random organic event
        val roll = Random.nextInt(100)
        if (roll < 35) {
            val randomPool = when {
                age < 15 -> listOf(
                    RandomEventData("Kamu memenangkan juara lomba cerdas cermat tingkat sekolah!", EventCategory.EDUCATION, "HAPPINESS_GOOD"),
                    RandomEventData("Kamu terkena flu musiman dan harus beristirahat beberapa hari di kasur.", EventCategory.HEALTH, "HEALTH_BAD"),
                    RandomEventData("Ayah membelikanmu hadiah kejutan karena perilakumu yang santun.", EventCategory.RELATIONSHIP, "HAPPINESS_GOOD")
                )
                age < 25 -> listOf(
                    RandomEventData("Teman mengajakmu menghadiri seminar teknologi dan festival anak muda.", EventCategory.GENERAL, "HAPPINESS_GOOD"),
                    RandomEventData("Pengeluaran tak terduga untuk servis kendaraan dan reparasi gadget.", EventCategory.FINANCE, "GENERAL"),
                    RandomEventData("Kamu rutin lari pagi setiap akhir pekan, tubuhmu terasa lebih bertenaga.", EventCategory.HEALTH, "HEALTH_GOOD"),
                    RandomEventData("Ada seseorang yang diam-diam menaruh hati dan sering mengirim pesan padamu.", EventCategory.RELATIONSHIP, "HAPPINESS_GOOD")
                )
                age < 50 -> listOf(
                    RandomEventData("Investasimu menghasilkan dividen positif yang menambah kas tahunan.", EventCategory.FINANCE, "HAPPINESS_GOOD"),
                    RandomEventData("Keluarga besar berkumpul dalam reuni tahunan yang penuh nostalgia hangat.", EventCategory.RELATIONSHIP, "HAPPINESS_GOOD"),
                    RandomEventData("Jadwal kerja yang padat membuat punggungmu sering pegal. Dokter menyarankan kurangi lembur.", EventCategory.HEALTH, "HEALTH_BAD"),
                    RandomEventData("Kamu dipercaya menjadi panitia kegiatan sosial di lingkungan tempat tinggalmu.", EventCategory.CAREER, "HAPPINESS_GOOD")
                )
                else -> listOf(
                    RandomEventData("Kamu menghabiskan sore santai merawat tanaman di teras rumah.", EventCategory.GENERAL, "HAPPINESS_GOOD"),
                    RandomEventData("Pemeriksaan tensi rutin menunjukkan kondisi kesehatanmu masih terjaga stabil.", EventCategory.HEALTH, "HEALTH_GOOD"),
                    RandomEventData("Sahabat lamamu menelepon untuk mengenang masa-masa muda dulu.", EventCategory.RELATIONSHIP, "HAPPINESS_GOOD")
                )
            }
            list.add(randomPool.random())
        }

        return list
    }

    private fun updateStageAndOccupation(age: Int, currentOcc: String): Pair<String, String> {
        val stage = when {
            age < 6 -> "Masa Kanak-kanak Awal"
            age < 13 -> "Pendidikan Dasar"
            age < 16 -> "Masa Remaja Awal"
            age < 19 -> "Masa Remaja Akhir"
            age < 30 -> "Dewasa Muda Meniti Karier"
            age < 50 -> "Masa Produktif Mapan"
            age < 65 -> "Paruh Baya Berpengalaman"
            else -> "Masa Pensiun & Menikmati Hidup"
        }

        val occ = when {
            age < 6 -> "Balita"
            age < 13 -> "Murid SD"
            age < 16 -> "Siswa SMP"
            age < 19 -> "Siswa SMA"
            age >= 65 && currentOcc != "Pensiunan" -> "Pensiunan"
            else -> currentOcc
        }

        return Pair(stage, occ)
    }

    fun interactWithRelationship(relId: String, actionType: String) {
        val current = _uiState.value
        val rel = current.relationships.find { it.id == relId } ?: return

        var closenessDelta = 0
        var happinessDelta = 0
        var cashDelta = 0L
        var energyDelta = -5
        var note = ""

        val hasEmpathetic = current.profile.personalityTraits.any { it.contains("Empatik", ignoreCase = true) }
        val traitBonus = if (hasEmpathetic) 5 else 0
        val repInfluence = when {
            current.stats.reputation >= 75 -> 4
            current.stats.reputation <= 35 -> -3
            else -> 0
        }

        var updatedFin = current.finance

        when (actionType) {
            "CHAT" -> {
                closenessDelta = Random.nextInt(5, 12) + traitBonus + repInfluence
                happinessDelta = 6
                note = if (current.stats.reputation >= 75)
                    "Mengobrol akrab. Dia sangat menghormati reputasimu yang terpandang."
                else "Mengobrol santai dari hati ke hati."
            }
            "GIFT" -> {
                val cost = 250_000L
                if (current.finance.cash >= cost) {
                    val (procFin, tx) = com.example.economy.EconomyEngine.processTransaction(
                        currentFinance = current.finance,
                        age = current.profile.age,
                        year = current.profile.currentYear,
                        type = TransactionType.PERSONAL_EXPENSE,
                        amount = -cost,
                        description = "Membeli kado untuk ${rel.name}",
                        source = "Hadiah & Keluarga"
                    )
                    if (tx != null) {
                        updatedFin = procFin
                        closenessDelta = Random.nextInt(12, 20) + traitBonus + repInfluence
                        happinessDelta = 10
                        note = "Memberikan kado yang sangat berkesan."
                    }
                } else {
                    closenessDelta = 3 + traitBonus
                    note = "Memberikan hadiah buatan tangan sederhana."
                }
            }
            "RESOLVE" -> {
                closenessDelta = 15 + traitBonus
                happinessDelta = 8
                note = "Menyelesaikan salah paham dan saling memaafkan."
            }
        }

        val updatedRels = current.relationships.map {
            if (it.id == relId) {
                it.copy(
                    closeness = (it.closeness + closenessDelta).coerceIn(0, 100),
                    statusDescription = note
                )
            } else it
        }

        val updatedStats = current.stats.copy(
            happiness = (current.stats.happiness + happinessDelta).coerceIn(0, 100),
            energy = (current.stats.energy + energyDelta).coerceIn(0, 100),
            reputation = (current.stats.reputation + 1).coerceIn(0, 100)
        )

        val newTimeline = current.timeline.toMutableList()
        newTimeline.add(
            0,
            TimelineEvent(
                id = "ev_rel_${System.currentTimeMillis()}",
                age = current.profile.age,
                year = current.profile.currentYear,
                text = "Kamu berinteraksi dengan ${rel.name}: $note",
                category = EventCategory.RELATIONSHIP
            )
        )

        _uiState.update {
            it.copy(
                relationships = updatedRels,
                stats = updatedStats,
                finance = updatedFin,
                timeline = newTimeline
            )
        }

        saveCurrentState()
        triggerHaptic()
    }

    fun updateAvatar(newAppearance: AvatarAppearance) {
        val updatedProfile = _uiState.value.profile.copy(avatar = newAppearance)
        _uiState.update { it.copy(profile = updatedProfile) }
        saveCurrentState()
        triggerHaptic()
    }

    fun purchaseClothingItem(item: ShopClothingItem) {
        val current = _uiState.value
        if (current.profile.ownedClothingIds.contains(item.id)) {
            equipClothingItem(item)
            return
        }

        val (updatedFinance, tx) = com.example.economy.EconomyEngine.processTransaction(
            currentFinance = current.finance,
            age = current.profile.age,
            year = current.profile.currentYear,
            type = TransactionType.SHOP_PURCHASE,
            amount = -item.price,
            description = "Membeli pakaian/aksesori: ${item.name}",
            source = "Wardrobe & Boutique",
            transactionId = "tx_shop_${item.id}_${System.currentTimeMillis()}"
        )

        if (tx == null) {
            _uiState.update { it.copy(errorMessage = "Saldo kas tidak mencukupi untuk membeli ${item.name}.") }
            return
        }

        val updatedOwnedList = current.profile.ownedClothingIds + item.id

        val currentAv = current.profile.avatar
        val updatedAvatar = when (item.category) {
            ClothingCategory.TOP -> currentAv.copy(topStyle = item.styleKey, topColor = item.colorKey)
            ClothingCategory.BOTTOM -> currentAv.copy(bottomStyle = item.styleKey, bottomColor = item.colorKey)
            ClothingCategory.SHOES -> currentAv.copy(shoesStyle = item.styleKey, shoesColor = item.colorKey)
            ClothingCategory.ACCESSORY -> currentAv.copy(accessory = item.styleKey)
            ClothingCategory.HAIR -> currentAv.copy(hairStyle = item.styleKey, hairColor = item.colorKey)
        }

        val updatedReputation = (current.stats.reputation + item.reputationBonus).coerceIn(0, 100)
        val updatedStats = current.stats.copy(reputation = updatedReputation)
        val updatedProfile = current.profile.copy(
            avatar = updatedAvatar,
            ownedClothingIds = updatedOwnedList
        )

        val newTimeline = current.timeline.toMutableList()
        newTimeline.add(
            0,
            TimelineEvent(
                id = "ev_shop_${System.currentTimeMillis()}",
                age = current.profile.age,
                year = current.profile.currentYear,
                text = "Membeli ${item.name} di boutique (+${item.reputationBonus} Reputasi).",
                category = EventCategory.FINANCE
            )
        )

        _uiState.update {
            it.copy(
                profile = updatedProfile,
                finance = updatedFinance,
                stats = updatedStats,
                timeline = newTimeline,
                errorMessage = null
            )
        }
        saveCurrentState()
        triggerHaptic()
    }

    fun equipClothingItem(item: ShopClothingItem) {
        val current = _uiState.value
        val currentAv = current.profile.avatar
        val updatedAvatar = when (item.category) {
            ClothingCategory.TOP -> currentAv.copy(topStyle = item.styleKey, topColor = item.colorKey)
            ClothingCategory.BOTTOM -> currentAv.copy(bottomStyle = item.styleKey, bottomColor = item.colorKey)
            ClothingCategory.SHOES -> currentAv.copy(shoesStyle = item.styleKey, shoesColor = item.colorKey)
            ClothingCategory.ACCESSORY -> currentAv.copy(accessory = item.styleKey)
            ClothingCategory.HAIR -> currentAv.copy(hairStyle = item.styleKey, hairColor = item.colorKey)
        }
        val updatedProfile = current.profile.copy(avatar = updatedAvatar)
        _uiState.update { it.copy(profile = updatedProfile) }
        saveCurrentState()
        triggerHaptic()
    }

    fun applyJob(job: JobOpportunity) {
        val current = _uiState.value
        if (current.profile.age < job.minAge) {
            _uiState.update { it.copy(errorMessage = "Usia minimal untuk ${job.title} adalah ${job.minAge} tahun.") }
            return
        }
        if (current.stats.intellect < job.minIntellect) {
            _uiState.update { it.copy(errorMessage = "Kecerdasanmu belum mencukupi standar seleksi (${job.minIntellect}).") }
            return
        }

        val updatedProfile = current.profile.copy(occupation = job.title)
        val updatedFinance = current.finance.copy(monthlyIncome = job.monthlySalary)
        val updatedStats = current.stats.copy(
            reputation = (current.stats.reputation + 10).coerceIn(0, 100),
            happiness = (current.stats.happiness + 15).coerceIn(0, 100)
        )

        val newTimeline = current.timeline.toMutableList()
        newTimeline.add(
            0,
            TimelineEvent(
                id = "ev_job_${System.currentTimeMillis()}",
                age = current.profile.age,
                year = current.profile.currentYear,
                text = "Diterima bekerja di ${job.company} sebagai ${job.title} (Gaji Rp ${job.monthlySalary}/bln).",
                category = EventCategory.CAREER
            )
        )

        _uiState.update {
            it.copy(
                profile = updatedProfile,
                finance = updatedFinance,
                stats = updatedStats,
                timeline = newTimeline,
                errorMessage = null
            )
        }

        saveCurrentState()
        triggerHaptic()
    }

    private fun checkAchievements(
        currentAchievements: List<GameAchievement>,
        stats: LifeStats,
        finance: FinancialState,
        profile: CharacterProfile,
        relationships: List<Relationship>
    ): List<GameAchievement> {
        return currentAchievements.map { ach ->
            if (ach.unlockedAtAge != null) ach
            else {
                val shouldUnlock = when (ach.id) {
                    "ach_scholar" -> stats.intellect >= 90
                    "ach_first_job" -> finance.monthlyIncome > 0
                    "ach_boss" -> finance.assets.any { it.category == "Bisnis" }
                    "ach_wealthy" -> finance.netWorth >= 100_000_000L
                    "ach_centenarian" -> profile.age >= 75
                    "ach_beloved" -> relationships.count { it.closeness >= 90 } >= 3
                    else -> false
                }
                if (shouldUnlock) ach.copy(unlockedAtAge = profile.age) else ach
            }
        }
    }

    fun startNewGame(
        name: String,
        gender: Gender,
        startAge: Int,
        birthCity: String,
        background: String,
        avatar: AvatarAppearance = AvatarAppearance(),
        personalityTraits: List<String> = listOf("Ambisius", "Kreatif")
    ) {
        val newProfile = repository.createDefaultProfile(
            name = name,
            gender = gender,
            startAge = startAge,
            birthCity = birthCity,
            backgroundTrait = background,
            avatar = avatar,
            personalityTraits = personalityTraits
        )
        val newStats = LifeStats(
            health = if (startAge > 60) 65 else 85,
            happiness = 80,
            intellect = if (startAge < 6) 30 else 75,
            reputation = 60,
            energy = if (startAge > 60) 60 else 90
        )
        val newFinance = repository.createDefaultFinance(startAge)
        val newRelationships = repository.createDefaultRelationships(startAge)
        val newTimeline = repository.createDefaultTimeline(startAge)
        val newAchievements = repository.createInitialAchievements()

        _uiState.update {
            it.copy(
                profile = newProfile,
                stats = newStats,
                finance = newFinance,
                relationships = newRelationships,
                timeline = newTimeline,
                achievements = newAchievements,
                isGameOver = false,
                lastActionResult = null,
                actionInputText = "",
                yearlySummaryDialog = null,
                showNewGameDialog = false,
                errorMessage = null
            )
        }

        saveCurrentState()
        triggerHaptic()
    }

    fun resetGame() {
        repository.clearGame()
        startNewGame(
            name = "Aditya Pratama",
            gender = Gender.MALE,
            startAge = 18,
            birthCity = "Jakarta",
            background = "Keluarga Menengah Pekerja Keras"
        )
    }

    private fun saveCurrentState() {
        val s = _uiState.value
        repository.saveGame(
            profile = s.profile,
            stats = s.stats,
            finance = s.finance,
            relationships = s.relationships,
            timeline = s.timeline,
            achievements = s.achievements
        )
    }

    private fun triggerHaptic() {
        if (!_uiState.value.vibrationEnabled) return
        try {
            val context = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(30)
                }
            }
        } catch (_: Exception) {}
    }
}
