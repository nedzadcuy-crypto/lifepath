package com.example.util

import java.text.NumberFormat
import java.util.Locale

object FormatUtils {
    private val indonesianLocale = Locale.forLanguageTag("id-ID")
    private val currencyFormat = NumberFormat.getCurrencyInstance(indonesianLocale).apply {
        maximumFractionDigits = 0
    }

    fun formatRupiah(amount: Long): String {
        return try {
            "Rp ${NumberFormat.getNumberInstance(indonesianLocale).format(amount)}"
        } catch (_: Exception) {
            "Rp $amount"
        }
    }
}
