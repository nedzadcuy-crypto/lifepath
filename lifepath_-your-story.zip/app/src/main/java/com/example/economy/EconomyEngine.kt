package com.example.economy

import com.example.model.*
import kotlin.math.max

object EconomyEngine {

    /**
     * Validates and applies a one-off transaction (from actions, shop purchases, small businesses, allowances).
     * Returns a pair of the updated FinancialState and the created CashTransaction (if approved).
     */
    fun processTransaction(
        currentFinance: FinancialState,
        age: Int,
        year: Int,
        type: TransactionType,
        amount: Long,
        description: String,
        source: String,
        transactionId: String? = null
    ): Pair<FinancialState, CashTransaction?> {
        val txId = transactionId ?: "tx_${System.currentTimeMillis()}_${(1000..9999).random()}"

        // Deduplication: prevent the same transaction from processing twice
        if (currentFinance.transactions.any { it.id == txId }) {
            return Pair(currentFinance, null)
        }

        // Outflow validation: prevent negative balance (cannot spend more than available cash)
        if (amount < 0 && (currentFinance.cash + amount) < 0) {
            return Pair(currentFinance, null)
        }

        val tx = CashTransaction(
            id = txId,
            age = age,
            year = year,
            type = type,
            amount = amount,
            description = description,
            source = source
        )

        val updatedCash = (currentFinance.cash + amount).coerceAtLeast(0L)
        val updatedTransactions = listOf(tx) + currentFinance.transactions

        val updatedFinance = currentFinance.copy(
            cash = updatedCash,
            transactions = updatedTransactions
        )

        return Pair(updatedFinance, tx)
    }

    /**
     * Deterministic Annual Evaluation when the player advances time (+1 Year).
     * ZERO automated money: money only changes if there is a verified employment salary,
     * verified business revenue, or verified debt/maintenance payments.
     */
    data class AnnualEconomicResult(
        val updatedFinance: FinancialState,
        val totalInflow: Long,
        val totalOutflow: Long,
        val netCashFlow: Long,
        val generatedTransactions: List<CashTransaction>
    )

    fun evaluateYearlyFlow(
        profile: CharacterProfile,
        finance: FinancialState,
        age: Int,
        year: Int
    ): AnnualEconomicResult {
        val newTransactions = mutableListOf<CashTransaction>()
        var annualInflow = 0L
        var annualOutflow = 0L

        // 1. Employment Salary: ONLY if character holds an actual job and is of legal working age (>=18 or formally employed)
        val hasLegitJob = profile.age >= 17 &&
                finance.monthlyIncome > 0 &&
                profile.occupation != "Bayi" &&
                profile.occupation != "Balita" &&
                profile.occupation != "Murid SD" &&
                profile.occupation != "Siswa SMP" &&
                profile.occupation != "Siswa SMA" &&
                profile.occupation != "Pengangguran"

        if (hasLegitJob) {
            val annualSalary = finance.monthlyIncome * 12
            annualInflow += annualSalary
            newTransactions.add(
                CashTransaction(
                    id = "tx_salary_${year}_${profile.lifeId}",
                    age = age,
                    year = year,
                    type = TransactionType.JOB_INCOME,
                    amount = annualSalary,
                    description = "Gaji tahunan dari profesi ${profile.occupation}",
                    source = "Pemberi Kerja / Perusahaan"
                )
            )
        }

        // 2. Business Income: ONLY if registered business assets exist with positive income contribution
        val businessAssets = finance.assets.filter { it.category == "Bisnis" || it.monthlyIncomeContribution > 0 }
        businessAssets.forEach { biz ->
            val annualBizProfit = biz.monthlyIncomeContribution * 12
            if (annualBizProfit > 0) {
                annualInflow += annualBizProfit
                newTransactions.add(
                    CashTransaction(
                        id = "tx_biz_${biz.id}_${year}",
                        age = age,
                        year = year,
                        type = TransactionType.BUSINESS_INCOME,
                        amount = annualBizProfit,
                        description = "Dividen & laba bersih dari ${biz.name}",
                        source = biz.name
                    )
                )
            }
        }

        // 3. Living Expenses:
        // Under 18 living with family: 0 living expenses charged to child's savings (family covers basics).
        // 18+ independent adult: applies monthly personal expense.
        val appliesPersonalExpenses = profile.age >= 18 && finance.monthlyExpense > 0
        if (appliesPersonalExpenses) {
            val annualPersonalCost = finance.monthlyExpense * 12
            annualOutflow += annualPersonalCost
            newTransactions.add(
                CashTransaction(
                    id = "tx_living_${year}_${profile.lifeId}",
                    age = age,
                    year = year,
                    type = TransactionType.PERSONAL_EXPENSE,
                    amount = -annualPersonalCost,
                    description = "Biaya hidup, konsumsi & kebutuhan pokok tahunan",
                    source = "Pengeluaran Mandiri"
                )
            )
        }

        // 4. Asset Maintenance: only if owned assets carry maintenance fees
        finance.assets.filter { it.monthlyMaintenance > 0 }.forEach { asset ->
            val annualMaintenance = asset.monthlyMaintenance * 12
            annualOutflow += annualMaintenance
            newTransactions.add(
                CashTransaction(
                    id = "tx_maint_${asset.id}_${year}",
                    age = age,
                    year = year,
                    type = TransactionType.OPERATING_COST,
                    amount = -annualMaintenance,
                    description = "Biaya perawatan & operasional ${asset.name}",
                    source = asset.name
                )
            )
        }

        // 5. Debt Installments: only if active debts exist
        finance.debts.forEach { debt ->
            val annualDebtPayment = (debt.monthlyPayment * 12).coerceAtMost(debt.totalAmount)
            if (annualDebtPayment > 0) {
                annualOutflow += annualDebtPayment
                newTransactions.add(
                    CashTransaction(
                        id = "tx_debt_${debt.id}_${year}",
                        age = age,
                        year = year,
                        type = TransactionType.OTHER,
                        amount = -annualDebtPayment,
                        description = "Cicilan tahunan untuk ${debt.name}",
                        source = "Lembaga Keuangan / Kreditur"
                    )
                )
            }
        }

        val netCashFlow = annualInflow - annualOutflow
        val newCash = (finance.cash + netCashFlow).coerceAtLeast(0L)

        // Decrement debt balances deterministically
        val updatedDebts = finance.debts.mapNotNull { debt ->
            val remaining = debt.totalAmount - (debt.monthlyPayment * 12)
            if (remaining > 0) debt.copy(totalAmount = remaining) else null
        }

        val updatedFinance = finance.copy(
            cash = newCash,
            debts = updatedDebts,
            transactions = newTransactions + finance.transactions
        )

        return AnnualEconomicResult(
            updatedFinance = updatedFinance,
            totalInflow = annualInflow,
            totalOutflow = annualOutflow,
            netCashFlow = netCashFlow,
            generatedTransactions = newTransactions
        )
    }

    /**
     * Validates AI-proposed financial deltas.
     * Prevents invalid or arbitrary money injection.
     */
    fun validateAiFinancialProposal(
        proposal: FinancialDelta,
        currentFinance: FinancialState,
        profile: CharacterProfile,
        actionText: String
    ): FinancialDelta {
        var validCashDelta = proposal.cashDelta
        val lower = actionText.lowercase()

        // 1. If spending money, cannot exceed existing cash
        if (validCashDelta < 0 && (currentFinance.cash + validCashDelta) < 0) {
            validCashDelta = -currentFinance.cash
        }

        // 2. If earning money via Free Action, must correspond to a verified realistic activity
        if (validCashDelta > 0) {
            val isLegitActivity = lower.contains("jual") ||
                    lower.contains("es krim") ||
                    lower.contains("bantu") ||
                    lower.contains("kerja") ||
                    lower.contains("usaha") ||
                    lower.contains("hadiah") ||
                    lower.contains("uang saku") ||
                    lower.contains("dividen") ||
                    lower.contains("proyek") ||
                    lower.contains("freelance") ||
                    lower.contains("bonus")

            if (!isLegitActivity) {
                // Reject unjustified money injection from AI prompt
                validCashDelta = 0L
            } else {
                // Cap young child casual earnings realistically (e.g. selling homemade ice cream max 150.000)
                if (profile.age < 13 && validCashDelta > 200_000L) {
                    validCashDelta = 50_000L // realistic small-time sale
                }
            }
        }

        // 3. Salary changes: cannot create full-time job salary for children under 17
        var validIncomeDelta = proposal.monthlyIncomeDelta
        if (profile.age < 17 && validIncomeDelta > 0) {
            validIncomeDelta = 0L
        }

        return proposal.copy(
            cashDelta = validCashDelta,
            monthlyIncomeDelta = validIncomeDelta
        )
    }
}
