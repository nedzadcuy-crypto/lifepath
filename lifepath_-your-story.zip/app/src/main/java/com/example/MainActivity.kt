package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.GameOverDialog
import com.example.ui.components.HeaderBar
import com.example.ui.components.NewGameDialog
import com.example.ui.components.SettingsDialog
import com.example.ui.components.YearlySummaryDialog
import com.example.ui.screens.AchievementsScreen
import com.example.ui.screens.CareerScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.RelationshipsScreen
import com.example.ui.screens.WardrobeStudioScreen
import com.example.ui.theme.*
import com.example.viewmodel.LifePathViewModel
import com.example.viewmodel.MainTab

class MainActivity : ComponentActivity() {

    private val viewModel: LifePathViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LifePathTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val snackbarHostState = remember { SnackbarHostState() }

                BackHandler(enabled = uiState.currentTab != MainTab.DASHBOARD) {
                    viewModel.onTabSelected(MainTab.DASHBOARD)
                }

                LaunchedEffect(uiState.errorMessage) {
                    uiState.errorMessage?.let { error ->
                        snackbarHostState.showSnackbar(
                            message = error,
                            duration = SnackbarDuration.Short
                        )
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = CharcoalBackground,
                    contentWindowInsets = WindowInsets.systemBars,
                    topBar = {
                        HeaderBar(
                            profile = uiState.profile,
                            onSettingsClick = { viewModel.setShowSettingsDialog(true) },
                            onNewGameClick = { viewModel.setShowNewGameDialog(true) }
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = CharcoalCard,
                            tonalElevation = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(68.dp)
                                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        ) {
                            NavigationBarItem(
                                selected = uiState.currentTab == MainTab.DASHBOARD,
                                onClick = { viewModel.onTabSelected(MainTab.DASHBOARD) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Timeline,
                                        contentDescription = "Kehidupan",
                                        modifier = Modifier.size(22.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = "Kehidupan",
                                        fontSize = 11.sp,
                                        fontWeight = if (uiState.currentTab == MainTab.DASHBOARD) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CharcoalBackground,
                                    selectedTextColor = ElectricTeal,
                                    indicatorColor = ElectricTeal,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("tab_dashboard")
                            )

                            NavigationBarItem(
                                selected = uiState.currentTab == MainTab.STUDIO,
                                onClick = { viewModel.onTabSelected(MainTab.STUDIO) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Checkroom,
                                        contentDescription = "Studio",
                                        modifier = Modifier.size(22.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = "Studio",
                                        fontSize = 11.sp,
                                        fontWeight = if (uiState.currentTab == MainTab.STUDIO) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CharcoalBackground,
                                    selectedTextColor = ElectricTeal,
                                    indicatorColor = ElectricTeal,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("tab_studio")
                            )

                            NavigationBarItem(
                                selected = uiState.currentTab == MainTab.RELATIONSHIPS,
                                onClick = { viewModel.onTabSelected(MainTab.RELATIONSHIPS) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.People,
                                        contentDescription = "Hubungan",
                                        modifier = Modifier.size(22.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = "Hubungan",
                                        fontSize = 11.sp,
                                        fontWeight = if (uiState.currentTab == MainTab.RELATIONSHIPS) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CharcoalBackground,
                                    selectedTextColor = AmberAccent,
                                    indicatorColor = AmberAccent,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("tab_relationships")
                            )

                            NavigationBarItem(
                                selected = uiState.currentTab == MainTab.CAREER,
                                onClick = { viewModel.onTabSelected(MainTab.CAREER) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.BusinessCenter,
                                        contentDescription = "Karier",
                                        modifier = Modifier.size(22.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = "Karier",
                                        fontSize = 11.sp,
                                        fontWeight = if (uiState.currentTab == MainTab.CAREER) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CharcoalBackground,
                                    selectedTextColor = ElectricTeal,
                                    indicatorColor = ElectricTeal,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("tab_career")
                            )

                            NavigationBarItem(
                                selected = uiState.currentTab == MainTab.ACHIEVEMENTS,
                                onClick = { viewModel.onTabSelected(MainTab.ACHIEVEMENTS) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.MilitaryTech,
                                        contentDescription = "Prestasi",
                                        modifier = Modifier.size(22.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = "Prestasi",
                                        fontSize = 11.sp,
                                        fontWeight = if (uiState.currentTab == MainTab.ACHIEVEMENTS) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CharcoalBackground,
                                    selectedTextColor = AmberAccent,
                                    indicatorColor = AmberAccent,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("tab_achievements")
                            )
                        }
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        Crossfade(targetState = uiState.currentTab, label = "tab_fade") { tab ->
                            when (tab) {
                                MainTab.DASHBOARD -> DashboardScreen(
                                    profile = uiState.profile,
                                    stats = uiState.stats,
                                    finance = uiState.finance,
                                    timeline = uiState.timeline,
                                    inputText = uiState.actionInputText,
                                    onInputChange = viewModel::onActionInputChanged,
                                    onSubmitAction = viewModel::submitFreeAction,
                                    isProcessingAction = uiState.isProcessingAction,
                                    lastActionResult = uiState.lastActionResult,
                                    onDismissActionResult = viewModel::clearLastActionResult,
                                    onAdvanceOneYear = viewModel::advanceOneYear,
                                    onOpenStudio = { viewModel.onTabSelected(MainTab.STUDIO) }
                                )

                                MainTab.STUDIO -> WardrobeStudioScreen(
                                    currentAppearance = uiState.profile.avatar,
                                    ownedClothingIds = uiState.profile.ownedClothingIds,
                                    finance = uiState.finance,
                                    onSaveAppearance = viewModel::updateAvatar,
                                    onPurchaseItem = viewModel::purchaseClothingItem
                                )

                                MainTab.RELATIONSHIPS -> RelationshipsScreen(
                                    relationships = uiState.relationships,
                                    onInteract = viewModel::interactWithRelationship
                                )

                                MainTab.CAREER -> CareerScreen(
                                    profile = uiState.profile,
                                    stats = uiState.stats,
                                    finance = uiState.finance,
                                    onApplyJob = viewModel::applyJob,
                                    onQuickAction = { prompt ->
                                        viewModel.onTabSelected(MainTab.DASHBOARD)
                                        viewModel.submitFreeAction(prompt)
                                    }
                                )

                                MainTab.ACHIEVEMENTS -> AchievementsScreen(
                                    profile = uiState.profile,
                                    finance = uiState.finance,
                                    achievements = uiState.achievements
                                )
                            }
                        }

                        // Dialogs
                        uiState.yearlySummaryDialog?.let { summary ->
                            YearlySummaryDialog(
                                summary = summary,
                                onDismiss = viewModel::dismissYearlySummary
                            )
                        }

                        if (uiState.isGameOver) {
                            GameOverDialog(
                                profile = uiState.profile,
                                finance = uiState.finance,
                                achievements = uiState.achievements,
                                onRestart = viewModel::resetGame
                            )
                        }

                        if (uiState.showNewGameDialog) {
                            NewGameDialog(
                                onDismiss = { viewModel.setShowNewGameDialog(false) },
                                onCreateCharacter = { name, gender, age, city, bg, avatar, traits ->
                                    viewModel.startNewGame(name, gender, age, city, bg, avatar, traits)
                                }
                            )
                        }

                        if (uiState.showSettingsDialog) {
                            SettingsDialog(
                                soundEnabled = uiState.soundEnabled,
                                vibrationEnabled = uiState.vibrationEnabled,
                                onToggleSound = viewModel::toggleSound,
                                onToggleVibration = viewModel::toggleVibration,
                                onResetGame = viewModel::resetGame,
                                onDismiss = { viewModel.setShowSettingsDialog(false) }
                            )
                        }
                    }
                }
            }
        }
    }
}
