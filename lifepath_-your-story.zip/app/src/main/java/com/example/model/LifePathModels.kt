package com.example.model

enum class Gender(val label: String) {
    MALE("Laki-laki"),
    FEMALE("Perempuan"),
    NON_BINARY("Non-biner")
}

data class BirthIdentity(
    val skinTone: String = "MEDIUM", // LIGHT, MEDIUM, TAN, WARM, DARK (PERMANENT)
    val naturalEyeColor: String = "DARK_BROWN", // DARK_BROWN, BLACK, HAZEL, BLUE, GREEN (PERMANENT)
    val faceShape: String = "OVAL", // ROUND, OVAL, SQUARE, HEART (PERMANENT)
    val birthMark: String = "NONE" // NONE, MOLE_CHEEK, FRECKLES, BEAUTY_MARK (PERMANENT)
)

enum class FamilyStructure(val label: String, val description: String) {
    BOTH_PARENTS("Kedua Orang Tua", "Tumbuh bersama ayah dan ibu kandung."),
    SINGLE_PARENT("Orang Tua Tunggal", "Dibesarkan oleh orang tua tunggal yang tangguh."),
    WITH_SIBLINGS("Keluarga Bersaudara", "Tumbuh bersama saudara kandung yang ramai."),
    ADOPTIVE_FAMILY("Keluarga Adopsi", "Disambut hangat dalam keluarga adopsi penuh kasih."),
    GUARDIAN("Tinggal Bersama Wali", "Diasuh oleh kakek/nenek atau wali keluarga.")
}

data class BirthCountry(
    val code: String,
    val name: String,
    val currencyName: String,
    val cities: List<String>
)

object WorldCountries {
    val list = listOf(
        BirthCountry("ID", "Indonesia", "Rupiah (Rp)", listOf("Jakarta", "Bandung", "Surabaya", "Yogyakarta", "Medan", "Denpasar", "Makassar")),
        BirthCountry("JP", "Jepang", "Yen (¥)", listOf("Tokyo", "Osaka", "Kyoto", "Sapporo", "Fukuoka")),
        BirthCountry("GB", "Inggris", "Pound (£)", listOf("London", "Manchester", "Edinburgh", "Birmingham")),
        BirthCountry("US", "Amerika Serikat", "Dollar ($)", listOf("New York", "San Francisco", "Chicago", "Seattle", "Austin"))
    )
}

data class AvatarAppearance(
    val skinTone: String = "MEDIUM", // LIGHT, MEDIUM, TAN, WARM, DARK
    val hairStyle: String = "SHORT_CURLY", // SHORT_CURLY, SLICK_BACK, BOB, LONG_WAVY, BUZZ_CUT, PONYTAIL
    val hairColor: String = "BLACK", // BLACK, BROWN, BLONDE, ELECTRIC_TEAL, AMBER, SILVER
    val topStyle: String = "T_SHIRT", // T_SHIRT, HOODIE, KEMEJA, BATIK, JAKET_KULIT, BLAZER
    val topColor: String = "ELECTRIC_TEAL", // ELECTRIC_TEAL, CHARCOAL, WHITE, NAVY, AMBER, RUBY_RED
    val bottomStyle: String = "JEANS", // JEANS, CHINOS, CELANA_BAHAN, JOGGER, ROK_MIDI
    val bottomColor: String = "DARK_DENIM", // DARK_DENIM, BLACK, KHAKI, GREY
    val shoesStyle: String = "SNEAKERS", // SNEAKERS, LEATHER_SHOES, BOOTS, SLIP_ON
    val shoesColor: String = "WHITE", // WHITE, BLACK, BROWN, ELECTRIC_TEAL
    val accessory: String = "NONE" // NONE, KACAMATA_MODERN, TOPI_BEANIE, KALUNG_EMAS, JAM_TANGAN
)

enum class ClothingCategory(val label: String) {
    HAIR("Gaya Rambut"),
    TOP("Atasan"),
    BOTTOM("Bawahan"),
    SHOES("Sepatu"),
    ACCESSORY("Aksesori")
}

data class ShopClothingItem(
    val id: String,
    val name: String,
    val category: ClothingCategory,
    val styleKey: String,
    val colorKey: String,
    val price: Long,
    val reputationBonus: Int,
    val description: String
)

data class PersonalityTrait(
    val id: String,
    val name: String,
    val description: String,
    val effectDescription: String
)

data class CharacterProfile(
    val id: String = "char_default",
    val name: String = "Aditya Pratama",
    val gender: Gender = Gender.MALE,
    val birthYear: Int = 2024,
    val currentYear: Int = 2024,
    val age: Int = 0, // ALWAYS STARTS AT 0
    val birthCountry: String = "Indonesia",
    val birthCity: String = "Jakarta",
    val familyStructure: FamilyStructure = FamilyStructure.BOTH_PARENTS,
    val occupation: String = "Bayi",
    val educationLevel: String = "Belum Sekolah",
    val lifeStageDescription: String = "Masa Awal Kehidupan (Bayi)",
    val isAlive: Boolean = true,
    val causeOfDeath: String? = null,
    val backgroundTrait: String = "Keluarga Menengah Pekerja Keras",
    val birthIdentity: BirthIdentity = BirthIdentity(),
    val avatar: AvatarAppearance = AvatarAppearance(),
    val personalityTraits: List<String> = listOf("Ambisius", "Kreatif"),
    val ownedClothingIds: List<String> = listOf("item_tshirt_teal", "item_jeans_dark", "item_sneakers_white")
) {
    val lifeId: String get() = id
    val firstName: String get() = name.split(" ").firstOrNull() ?: name
    val lastName: String get() = name.split(" ").drop(1).joinToString(" ")
}

data class LifeStats(
    val health: Int = 95,
    val happiness: Int = 90,
    val intellect: Int = 25,
    val reputation: Int = 50,
    val energy: Int = 95
) {
    fun clamped(): LifeStats = copy(
        health = health.coerceIn(0, 100),
        happiness = happiness.coerceIn(0, 100),
        intellect = intellect.coerceIn(0, 100),
        reputation = reputation.coerceIn(0, 100),
        energy = energy.coerceIn(0, 100)
    )
}

data class AssetItem(
    val id: String,
    val name: String,
    val value: Long,
    val category: String, // "Kendaraan", "Elektronik", "Properti", "Bisnis", "Investasi", "Barang"
    val monthlyMaintenance: Long = 0,
    val monthlyIncomeContribution: Long = 0
)

data class DebtItem(
    val id: String,
    val name: String,
    val totalAmount: Long,
    val monthlyPayment: Long
)

enum class TransactionType(val label: String) {
    JOB_INCOME("Gaji / Upah"),
    BUSINESS_INCOME("Pendapatan Usaha"),
    ALLOWANCE_GIFT("Uang Saku / Hadiah"),
    PERSONAL_EXPENSE("Biaya Hidup Pribadi"),
    BUSINESS_CAPITAL("Modal Usaha"),
    OPERATING_COST("Biaya Operasional"),
    SHOP_PURCHASE("Belanja Toko & Wardrobe"),
    ASSET_PURCHASE("Pembelian Aset"),
    MEDICAL_LEGAL("Biaya Medis / Darurat"),
    OTHER("Transaksi Lainnya")
}

data class CashTransaction(
    val id: String,
    val age: Int,
    val year: Int,
    val type: TransactionType,
    val amount: Long, // positive for inflow, negative for outflow
    val description: String,
    val source: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class FinancialState(
    val cash: Long = 0L, // Baby starts with 0 unless given gift/allowance
    val monthlyIncome: Long = 0L,
    val monthlyExpense: Long = 0L,
    val assets: List<AssetItem> = emptyList(),
    val debts: List<DebtItem> = emptyList(),
    val transactions: List<CashTransaction> = emptyList()
) {
    val totalAssetValue: Long get() = assets.sumOf { it.value }
    val totalDebtValue: Long get() = debts.sumOf { it.totalAmount }
    val netWorth: Long get() = cash + totalAssetValue - totalDebtValue
}

enum class RelationType(val label: String) {
    FATHER("Ayah"),
    MOTHER("Ibu"),
    SIBLING("Saudara"),
    FRIEND("Sahabat"),
    PARTNER("Pasangan"),
    BOSS("Atasan"),
    COLLEAGUE("Rekan"),
    CHILD("Anak"),
    GUARDIAN("Wali")
}

data class Relationship(
    val id: String,
    val name: String,
    val relationType: RelationType,
    val age: Int,
    val closeness: Int, // 0 - 100
    val personality: String,
    val occupation: String,
    val statusDescription: String
)

enum class EventCategory(val label: String) {
    GENERAL("Umum"),
    HEALTH("Kesehatan"),
    CAREER("Karier"),
    RELATIONSHIP("Hubungan"),
    FINANCE("Keuangan"),
    EDUCATION("Pendidikan"),
    MILESTONE("Pencapaian")
}

data class TimelineEvent(
    val id: String,
    val age: Int,
    val year: Int,
    val text: String,
    val category: EventCategory = EventCategory.GENERAL,
    val statDeltas: Map<String, Int> = emptyMap()
)

data class GameAchievement(
    val id: String,
    val title: String,
    val description: String,
    val iconName: String,
    val unlockedAtAge: Int? = null
)

data class FinancialDelta(
    val cashDelta: Long = 0L,
    val monthlyIncomeDelta: Long = 0L,
    val monthlyExpenseDelta: Long = 0L,
    val newAsset: AssetItem? = null,
    val newDebt: DebtItem? = null,
    val transactionType: TransactionType = TransactionType.OTHER,
    val transactionDescription: String = ""
)

data class RelationshipDelta(
    val relationId: String? = null,
    val name: String,
    val closenessDelta: Int,
    val note: String
)

data class ActionAiResult(
    val narrative: String,
    val actionValid: Boolean,
    val statChanges: Map<String, Int> = emptyMap(),
    val financialChanges: FinancialDelta = FinancialDelta(),
    val newEvents: List<String> = emptyList(),
    val relationshipChanges: List<RelationshipDelta> = emptyList(),
    val obstacleReason: String? = null,
    val isLocalSimulation: Boolean = false
)

data class JobOpportunity(
    val id: String,
    val title: String,
    val company: String,
    val minAge: Int,
    val minIntellect: Int,
    val minReputation: Int,
    val monthlySalary: Long,
    val educationRequired: String,
    val description: String
)

data class SkillItem(
    val id: String,
    val name: String,
    val level: Int, // 1 - 5
    val category: String
)

data class CompletedLifeRecord(
    val lifeId: String,
    val fullName: String,
    val gender: Gender,
    val birthYear: Int,
    val deathYear: Int,
    val finalAge: Int,
    val birthCity: String,
    val birthCountry: String,
    val finalOccupation: String,
    val finalNetWorth: Long,
    val causeOfDeath: String,
    val totalAchievementsUnlocked: Int,
    val keyMilestones: List<String>
)
